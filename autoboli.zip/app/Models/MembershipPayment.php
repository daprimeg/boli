<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MembershipPayment extends Model
{
   

    protected $guarded = [];

    // protected $fillable = [
    //     'user_id',
    //     'membership_id',
    //     'plan_id',
    //     'payment_date',
    //     'payment_method',
    //     'transaction_id',
    //     'payer_id',
    //     'charge_id',
    //     'amount',
    //     'currency',
    //     'payment_status',
    //     'webhook_received',
    //     'webhook_data',
    // ];

}
