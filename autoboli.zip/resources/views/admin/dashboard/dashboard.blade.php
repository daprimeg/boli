@extends('admin.partial.app')
@push('title') Dashboard @endpush
@section('css')
<style>

</style>
@endsection
@section('content')
   <div class="container-fluid card container-p-y" style="height: 300px; background-image: url({{asset('/public/themeadmin/images/backgrounds/Dots.png')}})">
       

   </div>
@endsection
@section('js')
   
@endsection