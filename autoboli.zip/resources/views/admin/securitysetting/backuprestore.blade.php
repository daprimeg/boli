@include('admin.partial.layout')


<div class="content-wrapper">






<div class="flex-grow-1 container-p-y container-xxl">
    <div class="card">
        <!-- <h5 class="card-header">VinSearch</h5> -->
        
        <div class="container">

<h1> Backup & Restore </br> Coming Soon</h1>

        @include('admin.partial.soon')



    </div>
</div>






















@include('admin.partial.footer')