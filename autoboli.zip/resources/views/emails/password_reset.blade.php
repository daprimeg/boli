<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<body>
    <p>Hello,</p>

    <p>Click the link below to reset your password:</p>

    <p>
        <a href="">sd</a>
    </p>

    <p>If you didn’t request a password reset, no action is required.</p>

    <p>Thanks,<br>AutoBoli Team</p>
</body>
</html>
