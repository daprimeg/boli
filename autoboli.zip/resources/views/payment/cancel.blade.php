<!DOCTYPE html>
<html>
<head>
    <title>Payment Cancelled</title>
</head>
<body>
    <h1>Payment Cancelled</h1>
    <p>Your payment was cancelled.</p>
    <p><a href="{{ route('pay.twelve') }}">Try again</a></p>
</body>
</html>