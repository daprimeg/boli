        <!-- / Layout page -->
        </div>

<!-- Overlay -->
<div class="layout-overlay layout-menu-toggle"></div>

<!-- Drag Target Area To SlideIn Menu On Small Screens -->
<div class="drag-target"></div>
</div>
<!-- / Layout wrapper -->

<!-- Core JS -->
<!-- build:js assets/vendor/js/theme.js -->

<!-- <script src="{{ asset('public/assets/vendor/libs/jquery/jquery.js') }}"></script> -->

<script src="{{ asset('public/assets/vendor/libs/popper/popper.js') }}"></script>
<script src="{{ asset('public/assets/vendor/js/bootstrap.js') }}"></script>
<script src="{{ asset('public/assets/vendor/libs/node-waves/node-waves.js') }}"></script>

<script src="{{ asset('public/assets/vendor/libs/@algolia/autocomplete-js.js') }}"></script>

<script src="{{ asset('public/assets/vendor/libs/pickr/pickr.js') }}"></script>

<script src="{{ asset('public/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js') }}"></script>

<script src="{{ asset('public/assets/vendor/libs/hammer/hammer.js') }}"></script>

<script src="{{ asset('public/assets/vendor/libs/i18n/i18n.js') }}"></script>

<script src="{{ asset('public/assets/vendor/js/menu.js') }}"></script>

<!-- endbuild -->

<!-- Vendors JS -->
<script src="{{ asset('public/assets/vendor/libs/plyr/plyr.js') }}"></script>

<!-- Main JS -->

<script src="{{ asset('public/assets/js/main.js') }}"></script>

<!-- Page JS -->
<script src="{{ asset('public/assets/js/app-academy-course-details.js') }}"></script>
</body>
</html>
