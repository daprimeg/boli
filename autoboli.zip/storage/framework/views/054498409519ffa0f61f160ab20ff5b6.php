 <div class="row">
    <div class="col-12 pt-3">
         <h4 class="card-title ">Vehicle</h4>
    </div>
     <div class="col-md-4">
        <div class="form-group">
            <label class="form-label" >Title <span class="text-danger" >*</span></label>
            <input type="text" name="title" class="form-control" required value="<?php echo e(old('title', isset($vehicle) ? $vehicle->title : '')); ?>">
        </div>
    </div>
        <div class="col-md-4">
                            <label class="form-label">Vehicle Type <span class="text-danger" >*</span></label>
                                <select name="vehicle_id" class="form-control vehicleTtypes" required>
                              <?php if($vehicle->vehicle_id): ?>
                                        <option value="<?php echo e($vehicle->vehicle_id); ?>" selected ><?php echo e($vehicle->vehicle_type->name); ?></option>
                                    <?php endif; ?>
                               </select>
                         </div>
                            <div class="col-md-4">
                                <label class="form-label">Make <span class="text-danger" >*</span></label>
                                <select name="make_id" class="form-control make" required>
                                    <?php if($vehicle->make_id): ?>
                                        <option value="<?php echo e($vehicle->make_id); ?>" selected ><?php echo e($vehicle->make->name); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>
                    
                            <div class="col-md-4">
                                <label class="form-label">Model <span class="text-danger" >*</span></label>
                                <select name="model_id" class="form-control model" required>
                              <?php if($vehicle->model_id): ?>
                                        <option value="<?php echo e($vehicle->model_id); ?>" selected ><?php echo e($vehicle->model->name); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Variant <span class="text-danger" >*</span></label>
                                <select name="variant_id" class="form-control variants" required>
                                    <?php if($vehicle->variant_id): ?>
                                        <option value="<?php echo e($vehicle->variant_id); ?>" selected ><?php echo e($vehicle->variant->name); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Body Type <span class="text-danger" >*</span></label>
                                <select name="body_id" class="form-control bodyTypes" required>
                                    <?php if($vehicle->body_id): ?>
                                        <option value="<?php echo e($vehicle->body_id); ?>" selected ><?php echo e($vehicle->body_types->name); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                     <label class="form-label">yaer</label>
                                      <input type="text" name="year" class="form-control" value="<?php echo e(old('year', $vehicle->year ?? '')); ?>">
                            </div>
<div class="col-md-4">
        <label class="form-label">VIN</label>
        <input type="text" name="vin" class="form-control" value="<?php echo e(old('vin_no', $vehicle->vin ?? '')); ?>">
</div>
<div class="col-md-12">
     <label class="form-label">Images</label>
     <textarea name="imported" rows="6" class="form-control " ><?php echo e(old('images', $vehicle->images ?? '')); ?></textarea>
</div>
</div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
</div>
<div class="row">
     <div class="col-12 pt-3">
         <h4 class="card-title ">Specification</h4>
    </div> 
    <div class="col-md-4">
         <label class="form-label">Doors</label>
         <input type="text" name="doors" class="form-control" value="<?php echo e(old('doors', $vehicle->doors ?? '')); ?>">
    </div>
<div class="col-md-4">
    <label class="form-label">Seats</label>
    <input type="text" name="seats" class="form-control" value="<?php echo e(old('seats   ', $vehicle->seats ?? '')); ?>">
</div>
    
<div class="col-md-4">
    <label class="form-label">Fuel Type</label>
    <input type="text" name="fuel_type" class="form-control" value="<?php echo e(old('fuel_type', $vehicle->fuel_type ?? '')); ?>">
</div>
 <div class="col-md-4">
    <label class="form-label">Transmission</label>
    <input type="text" name="transmission" class="form-control" value="<?php echo e(old('transmission', $vehicle->transmission ?? '')); ?>">
</div>
    <div class="col-md-4">
      <label class="form-label">CC</label>
       <input type="text" name="cc" class="form-control" value="<?php echo e(old('cc', $vehicle->cc ?? '')); ?>">
    </div>
        <div class="col-md-4">
                      <label class="form-label">Color</label>
                        <select name="color_id" class="form-control color">
                                  <?php if($vehicle->color_id): ?>
                                        <option value="<?php echo e($vehicle->color_id); ?>" selected ><?php echo e($vehicle->color->name); ?></option>
                                    <?php endif; ?>
                         </select>
    </div>
    <div class="col-md-4">
        <label class="form-label">Keys</label>
        <input type="text" name="keys" class="form-control" value="<?php echo e(old('keys', $vehicle->keys ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Euro Status</label>
        <input type="text" name="euro_status" class="form-control" value="<?php echo e(old('euro_status', $vehicle->euro_status ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">DOR (Date of Registration)</label>
        <input type="date" name="dor" class="form-control" value="<?php echo e(old('dor', $vehicle->dor ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Registration</label>
        <input type="text" name="reg" class="form-control" value="<?php echo e(old('reg', $vehicle->reg ?? '')); ?>">
    </div>

    <div class="col-md-4">
        <label class="form-label">Former Keepers</label>
        <input type="number" name="former_keepers" class="form-control" value="<?php echo e(old('former_keepers', $vehicle->former_keepers ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Mileage</label>
        <input type="text" name="mileage" class="form-control" value="<?php echo e(old('mileage', $vehicle->mileage ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Mileage Warranted</label>
        <input type="text" name="mileage_warranted" class="form-control" value="<?php echo e(old('mileage_warranted', $vehicle->mileage_warranted ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">MOT Expiry Date</label>
        <input type="date" name="mot_expiry_date" class="form-control" value="<?php echo e(old('mot_expiry_date', $vehicle->mot_expiry_date ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">MOT Due</label>
        <input type="date" name="mot_due" class="form-control" value="<?php echo e(old('mot_due', $vehicle->mot_due ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">V5</label>
        <input type="text" name="v5" class="form-control" value="<?php echo e(old('v5', $vehicle->v5 ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Engine Runs</label>
        <input type="text" name="engine_runs" class="form-control" value="<?php echo e(old('engine_runs', $vehicle->engine_runs ?? '')); ?>">
    </div>
    </div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
    </div>
<div class="row">
     <div class="col-12 pt-3">
         <h4 class="card-title ">Service History</h4>
    </div>

    <div class="col-md-4">
        <label class="form-label">Service History</label>
        <input type="text" name="service_history" class="form-control" value="<?php echo e(old('service_history', $vehicle->service_history ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">No Of Service</label>
        <input type="text" name="no_of_services" class="form-control" value="<?php echo e(old('no_of_services', $vehicle->no_of_services ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Last Service</label>
        <input type="text" name="last_service" class="form-control" value="<?php echo e(old('last_service', $vehicle->last_service ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Last Service Mileage</label>
        <input type="text" name="last_service_mileage" class="form-control" value="<?php echo e(old('last_service_mileage', $vehicle->last_service_mileage ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">DVSA Mileage</label>
        <input type="text" name="dvsa_mileage" class="form-control" value="<?php echo e(old('dvsa_mileage', $vehicle->dvsa_mileage ?? '')); ?>">
    </div>
    <div class="col-md-12">
        <label class="form-label">Service Note</label>
        <textarea name="service_notes" class="form-control"><?php echo e(old('service_notes', $vehicle->service_notes ?? '')); ?></textarea>
    </div>
</div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
</div>
<div class="row">
    <div class="col-12 pt-3">
         <h4 class="card-title ">Condition</h4>
    </div>
    <div class="col-md-4">
        <label class="form-label">Grade</label>
        <input type="text" name="grade" class="form-control" value="<?php echo e(old('grade', $vehicle->grade ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Inspection Report</label>
        <input type="text" name="inspection_report" class="form-control" value="<?php echo e(old('inspection_report', $vehicle->inspection_report ?? '')); ?>">
    </div>
     <div class="col-md-4">
        <label class="form-label">Other Report</label>
        <input type="text" name="other_report" class="form-control" value="<?php echo e(old('other_report', $vehicle->other_report ?? '')); ?>">
    </div>   
    <div class="col-md-4">
        <label class="form-label">Inspection Date</label>
        <input type="date" name="inspection_date" class="form-control" value="<?php echo e(old('inspection_date', $vehicle->inspection_date ?? '')); ?>">
    </div>
</div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
</div>
<div class="row">
    <div class="col-12 pt-3">
         <h4 class="card-title ">Pricing</h4>
    </div>
    <div class="col-md-4">
        <label class="form-label">Bidding History</label>
        <input type="text" name="bidding_history" class="form-control" value="<?php echo e(old('bidding_history', $vehicle->bidding_history ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Last Bid</label>
        <input type="text" name="last_bid" class="form-control" value="<?php echo e(old('last_bid', $vehicle->last_bid ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Bidding Status</label>
        <input type="text" name="bidding_status" class="form-control" value="<?php echo e(old('bidding_status', $vehicle->bidding_status ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">CAP New</label>
        <input type="text" name="cap_new" class="form-control" value="<?php echo e(old('cap_new', $vehicle->cap_new ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">CAP Retails</label>
        <input type="text" name="cap_new" class="form-control" value="<?php echo e(old('cap_new', $vehicle->cap_new ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">CAP Clean</label>
        <input type="text" name="cap_clean" class="form-control" value="<?php echo e(old('cap_clean', $vehicle->cap_clean ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">CAP Average</label>
        <input type="text" name="cap_average" class="form-control" value="<?php echo e(old('cap_average', $vehicle->cap_average ?? '')); ?>">
    </div>

    <div class="col-md-4">
        <label class="form-label">CAP Below</label>
        <input type="text" name="cap_below" class="form-control" value="<?php echo e(old('cap_below', $vehicle->cap_below ?? '')); ?>">
    </div>

    <div class="col-md-4">
        <label class="form-label">Glass New</label>
        <input type="text" name="glass_new" class="form-control" value="<?php echo e(old('glass_new', $vehicle->glass_new ?? '')); ?>">
    </div>


    <div class="col-md-4">
        <label class="form-label">Glass Retail</label>
        <input type="text" name="glass_retail" class="form-control" value="<?php echo e(old('glass_retail', $vehicle->glass_retail ?? '')); ?>">
    </div>

    <div class="col-md-4">
        <label class="form-label">Glass Trade</label>
        <input type="text" name="glass_trade" class="form-control" value="<?php echo e(old('glass_trade', $vehicle->glass_trade ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">AutoTrader Retail Value</label>
        <input type="text" name="autotrader_retail_value" class="form-control" value="<?php echo e(old('autotrader_retail_value', $vehicle->autotrader_retail_value ?? '')); ?>">
    </div>

    <div class="col-md-4">
        <label class="form-label">AutoTrader Trade Value</label>
        <input type="text" name="autotrader_trade_value" class="form-control" value="<?php echo e(old('autotrader_trade_value', $vehicle->autotrader_trade_value ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Buy Now Price</label>
        <input type="text" name="buy_now_price" class="form-control" value="<?php echo e(old('buy_now_price', $vehicle->buy_now_price ?? '')); ?>">
    </div>
</div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
</div>
<div class="row">
    <div class="col-12 pt-3">
         <h4 class="card-title ">Tyres Condition</h4>
    </div>
    <div class="col-md-4">
        <label class="form-label">Tyres Condition</label>
        <input type="text" name="tyres_condition" class="form-control" value="<?php echo e(old('tyres_condition', $vehicle->tyres_condition ?? '')); ?>">
    </div>
</div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
</div>
<div class="row">
    <div class="col-12 pt-3">
         <h4 class="card-title ">Features </h4>
    </div>
    <div class="col-md-12">
        <label class="form-label">Features</label>
        <textarea name="features" class="form-control"><?php echo e(old('features', $vehicle->features ?? '')); ?></textarea>
    </div>
    <div class="col-md-12">
        <label class="form-label">Equipment</label>
        <textarea name="equipment" class="form-control"><?php echo e(old('equipment', $vehicle->equipment ?? '')); ?></textarea>
    </div>
</div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
</div>
<div class="row">
    <div class="col-12 pt-3">
         <h4 class="card-title ">More fields </h4>
    </div>
    <div class="col-md-12">
        <label class="form-label">Additional Information</label>
        <textarea name="additional_information" class="form-control"><?php echo e(old('additional_information', $vehicle->additional_information ?? '')); ?></textarea>
    </div>
    <div class="col-md-4">
        <label class="form-label">Imported</label>
        <input type="text" name="imported" class="form-control" value="<?php echo e(old('imported', $vehicle->imported ?? '')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label">Declarations</label>
        <input type="text" name="declarations" class="form-control" value="<?php echo e(old('declarations', $vehicle->declarations ?? '')); ?>">
    </div>
</div>
<div class="row py-10">
    <div class="col-12">
        <p style="border-bottom: 1px solid #44485e" ></p>
    </div>
</div>
<div class="row">
    <div class="col-12 pt-3">
         <h4 class="card-title ">DAMAGE REPORT </h4>
    </div>
 <div class="col-md-12">
        <label class="form-label">Damage  Images</label>
        <textarea name="damaged_images" class="form-control"><?php echo e(old('damaged_images', $vehicle->damaged_images ?? '')); ?></textarea>
                           </div>
    <div class="col-md-12">
        <label class="form-label">Damage  Details</label>
        <textarea name="damage_details" class="form-control"><?php echo e(old('damage_details', $vehicle->damage_details ?? '')); ?></textarea>
    </div>
    </div>



    




    





    

    



    





    



    











    








   


    

 
                      
<?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/vehicles/form.blade.php ENDPATH**/ ?>