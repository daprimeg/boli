<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed</title>
</head>
<body>
    <h1>Payment Failed</h1>
    <p>There was an error processing your payment.</p>
    <?php if(session('error')): ?>
        <p style="color: red;"><?php echo e(session('error')); ?></p>
    <?php endif; ?>
    <p><a href="<?php echo e(route('test.payment.form')); ?>">Try again</a></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/payment_failed.blade.php ENDPATH**/ ?>