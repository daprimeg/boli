<?php $__env->startPush('title'); ?> Billing Plan <?php $__env->stopPush(); ?>

<?php $__env->startSection('css'); ?>

<style>

      #card-element {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background-color: #f8f9fa;
            margin-bottom: 15px;
        }

</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container-xxl flex-grow-1 container-p-y">
      <div class="row">
          <div class="col-md-6">
            
            <?php if(!$current): ?>
            <div class="card mb-6">
                <h5 class="card-header">Subscribe Plan</h5>
                <div class="card-body">
                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                     <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                     <?php if(session('error')): ?>
                     <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>

                    <form id="creditCardForm" method="post" action="<?php echo e(url('/subscriptions_submit')); ?>" class="row g-6">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="payment_method" value="" />
                        
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label w-100" for="paymentCard">Plan</label>
                                <select required class="form-control" name="plan_id" id="">
                                    <option value="">Select Plan</option>
                                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->plan_name); ?> - £ <?php echo e($item->price); ?> / <?php echo e($item->duration_unit); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <span></span>
                        </div>

                        <div class="col-md-12">
                            <label class="form-label w-100" for="paymentCard">Card Number</label>
                            <div class="pt-3 payment-card">
                                <div class="form-group">
                                    <div id="card-element"></div>
                                    <div id="card-errors" style="color: red;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mt-6 text-center">
                            <button type="submit" class="btn btn-primary me-3">Submit</button>
                        </div>

                    </form>
                </div>
             </div>
             <?php endif; ?>

          </div>

          <div class="col-md-12">
              <div class="card">
                 <h5 class="card-header text-md-start text-center">Billing History</h5>
                 <div class="card-datatable border-top">
                        <table class="invoice-list-table table border-top">
                            <thead>
                                 <tr>
                                    <th>Date</th>
                                    <th>Plan Name</th>
                                    <th>Start</th>
                                    <th>Expiry</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                             <tbody>
                                <?php $__currentLoopData = $membership; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$item->payment): ?>
                                <?php continue; ?>
                                <?php endif; ?>
                                    <tr>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><?php echo e($item->plan->plan_name); ?></td>
                                        <td><?php echo e(date('d-M-Y',strtotime($item->membership_start_date))); ?></td>
                                        <td><?php echo e(date('d-M-Y',strtotime($item->membership_expiry_date))); ?></td>
                                        <td><?php echo e($item->payment->amount); ?> <?php echo e($item->payment->currency); ?></td>
                                        <td>
                                             <?php if($current && $current->id == $item->id): ?>
                                            <span class="badge bg-secondary">Active</span>
                                            <?php else: ?>
                                            <span class="badge bg-danger">Expired</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </tbody>
                          </table>
                       </div>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

     <script src="https://js.stripe.com/v3/"></script>
     <script>
     $(document).ready(function () {

        let stripe = Stripe("<?php echo e(env('STRIPE_PUBLISHABLE_KEY')); ?>");
        let elements = stripe.elements();
        let card = elements.create('card');
        card.mount('#card-element');

        $('select[name=plan_id]').change(function(e){ 
            if($(this).val() == 2){
                $('.payment-card').hide();
            }else{
                $('.payment-card').show();
            }
        }).trigger('change');


        async function checkpayment(){

                $('#card-errors').text('');
                let response = await stripe.createPaymentMethod({
                    type: 'card',
                    card: card,
                });
                if(response.error){
                    $('input[name=payment_method]').val('');
                    $('#card-errors').text(response.error.message); 
                    return false;
                }else{
                    $('input[name=payment_method]').val(response.paymentMethod.id);
                    return true;   
                }
        }

        
        $('#creditCardForm').on('submit', async function (e) {
            if($('select[name=plan_id]').val() == 2){
                return true; 
            }
            e.preventDefault();
            const success = await checkpayment();
            if(success){
                this.submit();
            }
        });

    });   
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/dashboard/subscriptions.blade.php ENDPATH**/ ?>