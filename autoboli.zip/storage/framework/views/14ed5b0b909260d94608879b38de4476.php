<?php $__env->startPush('title'); ?> Interest <?php $__env->stopPush(); ?>

<?php $__env->startSection('css'); ?>

    <style>
        .form-label{
            padding-top: 18px;
            padding-bottom: 6px;
            font-size: 15px;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="col-md-12">

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header border-bottom">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="card-title">Edit Interest</h5>
                            </div>
                            <div class="col-md-6 text-end">
                                 <a href="<?php echo e(url('/interest')); ?>" class="btn btn-primary">Back To List</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                 
                        <form class="pt-4" action="<?php echo e(url('/interest/')); ?>" method="POST" enctype="multipart/form-data"  >
                            <?php echo csrf_field(); ?>
                    
                            <div class="row">

                                <div class="col-12 pt-3">
                                    <h4 class="card-title ">Primary</h4>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                                    <input type="text" value="<?php echo e(old('title')); ?>" name="title" class="form-control" required>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label for="make_id" class="form-label">Make <span class="text-danger">*</span></label> <br>
                                    <select name="make_id" class="form-control form-select" required>
                                       
                                    </select>
                                </div>          

                                <div class="mb-3 col-md-4">
                                    <label for="model_id" class="form-label">Model <span class="text-danger">*</span></label> <br>
                                    <select name="model_id" class="form-select form-control" required>
                                        
                                    </select>
                                </div>
                                
                                <div class="mb-3 col-md-4">
                                    <label for="model_variant_id" class="form-label">Model Variant </label> <br>
                                    <select name="variant_id" class="form-select form-control">
                                       
                                    </select>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label for="year_from" class="form-label">Year</label>
                                    <div class="d-flex">
                                        <div class="box w-100">
                                            <select name="year_from" class="form-select" >
                                                <option value="">From</option>
                                                   <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(old('year_from') == $year): ?> selected <?php endif; ?> value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="box w-100">
                                            <select name="year_to" class="form-select" >
                                                <option value="">To</option>
                                                   <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(old('year_to') == $year): ?> selected <?php endif; ?> value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label class="form-label">Mileage</label>
                                    <div class="d-flex">
                                        <div class="box w-100">
                                            <input name="mileage_from" value="<?php echo e(old('mileage_from')); ?>" step="any" placeholder="From" type="number" class="form-control"  />
                                        </div>
                                        <div class="box w-100">
                                            <input name="mileage_to" value="<?php echo e(old('mileage_to')); ?>" step="any" placeholder="To" type="number" class="form-control"  />
                                        </div>
                                    </div>
                                </div>

                     

                                <div class="col-12 pt-3">
                                    <h4 class="card-title ">Secondry</h4>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label for="Fuel Type" class="form-label">Fuel Type</label>
                                    <select name="fuel_type" class="form-select" >
                                        <option value="">Select Fuel Type</option>
                                        <?php $__currentLoopData = $fuel_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($item == old('fuel_type')): ?> selected <?php endif; ?> value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label class="form-label">CC</label>
                                    <div class="d-flex">
                                        <div class="box w-100">
                                            <select name="cc_from" class="form-select">
                                                <option value="">From</option>
                                                <?php $__currentLoopData = $cc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(old('cc_from') == $c): ?> selected <?php endif; ?> value="<?php echo e($c); ?>"><?php echo e($c); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="box w-100">
                                            <select name="cc_to" class="form-select">
                                                <option value="">To</option>
                                                <?php $__currentLoopData = $cc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(old('cc_to') == $c): ?> selected <?php endif; ?> value="<?php echo e($c); ?>"><?php echo e($c); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3 col-md-4">
                                    <label class="form-label">Price</label>
                                    <div class="d-flex">
                                        <div class="box w-100">
                                            <input name="price_from" value="<?php echo e(old('price_from')); ?>" step="any" placeholder="From" type="number" class="form-control"  />
                                        </div>
                                        <div class="box w-100">
                                            <input name="price_to" step="any" value="<?php echo e(old('price_to')); ?>" placeholder="To" type="number" class="form-control"  />
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label for="transmission" class="form-label">Transmission</label>
                                    <select name="transmission" class="form-select">
                                        <option value="">Select Transmission</option>
                                        <?php $__currentLoopData = $transmission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if(old('transmission') == $item): ?> selected <?php endif; ?> value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                                    </select>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label for="grade" class="form-label">Grade</label>
                                    <select name="grade" class="form-select">
                                        <option value="">Select Grade</option>
                                        <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option <?php if(old('grade') == $item): ?> selected <?php endif; ?> value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                                    </select>
                                </div>

                                <div class="mb-3 col-md-4">
                                    <label class="form-label">Former Keepers</label>
                                    <input type="number" value="<?php echo e(old('former_keeper')); ?>" name="former_keeper" class="form-control">
                                </div>

                                <div class="col-12 text-center pt-3">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>


<script>


    $('select[name=make_id]').select2({
        placeholder: 'Select Make',
        allowClear: true,
        ajax: {
            url: "<?php echo e(url('/admin/masters/makes/getMakes')); ?>",
            dataType: 'json',
            
        }
    }).on('change', function () {

        $('select[name=model_id]').val(null).trigger('change');
        $('select[name=variant_id]').val(null).trigger('change');
        
    });


    $('select[name=model_id]').select2({
        placeholder: 'Select Model',
        allowClear: true,
        ajax: {
            url: "<?php echo e(url('/admin/masters/models/getModels')); ?>",
            dataType: 'json',
            data: function (params) {
                return {
                    q: params.term, // search term
                    make_id: $('select[name=make_id]').val()
                };
            }
        }
    }).on('change', function () {
        $('select[name=variant_id]').val(null).trigger('change');
    });
    
    $('select[name=variant_id]').select2({
        placeholder: 'Select Variant',
        allowClear: true,
        ajax: {
            url: "<?php echo e(url('/admin/masters/variants/getVariants')); ?>",
            dataType: 'json',
            data: function (params) {
                return {
                    q: params.term, // search term
                    model_id: $('select[name=model_id]').val()
                };
            }
        }
    });


    $('select[name=fuel_type]').change(function (e) { 

        if($(this).val() == 'Electric'){   
            $('select[name=cc_from]').parent().parent().parent().hide();
            $('select[name=cc_from]').val('');
            $('select[name=cc_to]').val('');

        }else{
            $('select[name=cc_from]').parent().parent().parent().show();
        }
    }).trigger('change');

    



</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/interests/create.blade.php ENDPATH**/ ?>