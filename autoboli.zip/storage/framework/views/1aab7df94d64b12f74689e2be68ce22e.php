        
        <div class="filters-sidebar border-end  text-white py-3" style="background-color: #0f1c2c; width: 281px; z-index: 1;">
            <div class="px-3" style="margin-bottom: -25px !important; font-size: 1.5rem; font-weight: 500;  border-bottom: 2px solid rgba(107, 104, 104, 0.413); padding-bottom: 5px; color: var(--bs-heading-color) !important; ">Smilar Vehicles</div>
           <div class="d-flex justify-content-between align-items-center pt-7 px-3">
                <span class="mb-0" style=" font-size: 15px">Filters</span>
                    <a href="<?php echo e(URL::to('#')); ?>" class="btn" style="text-decoration: underline; text-decoration-color: #07509a; font-size: 15px; margin-right: -20px;">Clear All</a> 
            </div>
            
            <form method="GET" action="<?php echo e(URL::to('/vehicles/index')); ?>">
               <div class="row px-3">
                    <!-- Data Dropdown (left) -->
                    <div class="col-md-3">
                        <div class="form-group">
                            <div class="dropdown ">
                                <button class="btn border dropdown-toggle  text-left py-1 px-2" type="button"
                                       style="font-size: 15px;" id="dataDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    Data
                                </button>
                                <div class="dropdown-menu " aria-labelledby="dataDropdown">
                                    <a class="dropdown-item" href="#" data-value="">All</a>
                                    <?php $__currentLoopData = $auctionsPlatform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" href="#" data-value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <input type="hidden" name="data_id" id="data_id">
                            </div>
                        </div>
                    </div>

                    <!-- Platform Dropdown (right) -->
                    <div class="col-md-3 ml-2">
                        <div class="form-group">
                            <div class="dropdown ">
                                <button class="btn border dropdown-toggle  text-left py-1 px-1" type="button"
                                       style="font-size: 15px;" id="platformDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    Platform
                                </button>
                                <div class="dropdown-menu " aria-labelledby="platformDropdown">
                                    <a class="dropdown-item" href="#" data-value="">All</a>
                                    <?php $__currentLoopData = $auctionsPlatform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" href="#" data-value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <input type="hidden" name="platform_id" id="platform_id">
                            </div>
                        </div>
                    </div>
                            <div class="col-md-5 d-flex justify-content-end align-items-center">
                                <div class="form-group mb-0">
                                    <span style="font-size:15px; margin-right: -15px">15,276</span>
                                </div>
                            </div>
                </div>
            </form>

            
            <div class="vehicle-list mt-4 ">
               <div class="form-group mt-4">    
                                    

                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="vehicle-card mb-4 border-top  " style="border-radius: 2px;  ">
                            
                        
                            <button class="btn btn1 btn-primary w-100 dropdown-toggle text-start  collapsed"
                                    type="button"
                                    style="justify-content: space-between; font-weight: 300; border-color:#44485e; box-shadow: none;"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#vehicle-<?php echo e($v->id); ?>"
                                    aria-controls="vehicle-<?php echo e($v->id); ?>">
                                    <div class="text-left" > 
                                        <p class="m-0" style="text-align: left; font-size: 15px; "><?php echo e(strtoupper($v->make->name)); ?></p>
                                        <p class="m-0" style="text-align: left; font-size: 15px;  "> <?php echo e($v->model->name); ?> <?php echo e($v->year); ?></p>
                                </div>
                            </button>

                            
                        <a href="<?php echo e($v->id); ?>"  >  
                            <div class="collapse" style="padding: 17px; padding-top: 0px;" id="vehicle-<?php echo e($v->id); ?>">
                                <div class="">
                                      
                                 
                                    <div class="mb-2" style="  text-decoration: none;">
                                              <button class="pickup-badge btn border my-2 " style="font-size: 15px; background-color: var();
                                               border: 1px solid var(--bs-primary) !important; color: var(--bs-heading-color)"><?php echo e($vehicle->auction->platform->name); ?></button>
                                        <span class="ms-2"><?php echo e(date('j/n/Y_H:i', strtotime($v->pickup_at ?? now()))); ?></span>
                                    </div>
                                          

                                            
                                            <img src="<?php echo e($v->getImage()); ?>"
                                                alt="Vehicle Image"
                                                class="vehicle-image mb-2"
                                                style="border-radius: 10px; max-width: 100%; height: 100%; display: block; margin-right: auto;">
                                        
                                     </div> 
                            </div>
                        </a>
                        
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


            </div>
        </div>
        
<?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/vehicles/show/sidebar.blade.php ENDPATH**/ ?>