

<?php $__env->startPush('title'); ?> Ticket <?php $__env->stopPush(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .form-label{
            padding-top: 18px;
            padding-bottom: 6px;
            font-size: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <div class="container-xxl flex-grow-1 container-p-y">
                <h3>Ticket Details</h3>
                <div class="card mb-4">
                    <div class="card-body">
                        <p><strong>Issue Topic:</strong> <?php echo e($ticket->issue_topic); ?></p>
                        <p><strong>Issue Type:</strong> <?php echo e($ticket->issue_type); ?></p>
                        <p><strong>Priority:</strong> <?php echo e($ticket->priority); ?></p>
                        <p><strong>Status:</strong>
                            <?php
                            $statuses = ['Open', 'In Progress', 'Resolved', 'Closed'];
                            ?>
                            <?php echo e($statuses[$ticket->status] ?? 'Unknown'); ?>

                        </p>
                        <p><strong>Created At:</strong> <?php echo e($ticket->created_at->format('d M Y H:i')); ?></p>
                        <p><strong>Details:</strong><br><?php echo $ticket->details; ?></p>
                        <?php if($ticket->attachment): ?>
                        <p><strong>Attachment:</strong>
                            <a href="<?php echo e(asset('/public/uploads/tickets/' . $ticket->attachment)); ?>" target="_blank">Download</a>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                <h4>Replies</h4>
                <?php $__currentLoopData = $ticket->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <p>
                            <strong><?php echo e($reply->is_admin ? 'Admin' : 'You'); ?>:</strong>
                            <small class="text-muted float-end"><?php echo e($reply->created_at->format('d M Y H:i')); ?></small>
                        </p>
                        <p><?php echo e($reply->message); ?></p>
                        <?php if($reply->attachment): ?>
                        <p><strong>Attachment:</strong>
                            <a href="<?php echo e(asset('storage/ticket_replies/' . $reply->attachment)); ?>" target="_blank">Download</a>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php if($ticket->status != 3): ?>
                    <div class="card mt-4">
                        <div class="card-body">
                            <h5>Add a Reply</h5>
                            <form action="<?php echo e(route('ticket.reply', $ticket->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="message" class="form-label">Message:</label>
                                    <textarea name="message" id="message" class="form-control" rows="4" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="attachment" class="form-label">Attachment (optional):</label>
                                    <input type="file" name="attachment" id="attachment" class="form-control">
                                </div>
                                <button type="submit" class="btn btn-primary">Send Reply</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                
                <?php if($ticket->status == 3): ?>
                        <?php if(is_null($ticket->feedback) && is_null($ticket->rating)): ?>
                            <div class="card mt-4">
                                <div class="card-body">
                                    <h5>Submit Feedback</h5>
                                    <form action="<?php echo e(route('ticket.feedback', $ticket->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="rating" class="form-label">Rating (1 to 5):</label>
                                            <select name="rating" id="rating" class="form-select" required>
                                                <option value="">Select Rating</option>
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="feedback" class="form-label">Feedback:</label>
                                            <textarea name="feedback" id="feedback" class="form-control" rows="4" required></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-success">Submit Feedback</button>
                                    </form>
                                </div>
                            </div>
                        <?php else: ?>
                        <div class="card mt-4">
                            <div class="card-body">
                                <h5>Feedback Submitted</h5>
                                <p><strong>Rating:</strong> <?php echo e($ticket->rating); ?>/5</p>
                                <p><strong>Feedback:</strong><br><?php echo e($ticket->feedback); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/ticket/view.blade.php ENDPATH**/ ?>