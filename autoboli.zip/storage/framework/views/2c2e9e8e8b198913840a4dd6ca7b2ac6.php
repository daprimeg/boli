<?php if(count($vehicles)): ?>
<table class="table">
    <thead>
        <tr>
            <th>Vehicle</th>
            <th>Lot No</th>
            <th>Auction Date</th>
            <th>Year</th>
            <th>CC</th>
            <th>Mileage</th>
            <th>Transmission</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($vehicle->make->name ?? ''); ?>

                <?php echo e($vehicle->model->name ?? ''); ?>

                <?php echo e($vehicle->variant->name ?? ''); ?>

            </td>
            <td><?php echo e($vehicle->auction->lot_number ?? '-'); ?></td>
            <td><?php echo e($vehicle->auction->auction_date ?? '-'); ?></td>
            <td><?php echo e($vehicle->year->year ?? '-'); ?></td>
            <td><?php echo e($vehicle->cc ?? '-'); ?></td>
            <td><?php echo e($vehicle->mileage ?? '-'); ?></td>
            <td><?php echo e($vehicle->transmission ?? '-'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
    <div class="alert alert-warning">No vehicles found matching the filters.</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\autoboli\resources\views/partials/vehicle_table.blade.php ENDPATH**/ ?>