

<?php $__env->startPush('title'); ?> Blog <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>
<style>

   .form-label{
         padding-top: 18px;
         padding-bottom: 6px;
         font-size: 15px;
   }

   .ck-editor__editable {
        min-height: 300px !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <div class="container-fluid container-p-y">
      <div class="row g-6"> 
            <div class="col-md-12">


         <div class="card">
            <div class="card-header border-bottom">
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="card-title"><?php echo e($blog->title); ?></h5>
                            <small>
                            <?php if($blog->category): ?>
                                <span class="badge bg-secondary"><?php echo e($blog->category->name); ?></span>
                            <?php endif; ?>
                            Posted on: <?php echo e($blog->date); ?> 
                            | By: <?php echo e($blog->author->name ?? 'Unknown'); ?>

                        </small>
                    </div>
                    <div class="col-md-6 text-end">
                            
                    </div>
                </div>
            </div>
            <div class="card-body">

                <?php if($blog->image): ?>
                    <div  class="text-center" > 
                        <img style="max-width: 300px" src="<?php echo e(asset('public/uploads/blogs/'.$blog->image)); ?>" alt="<?php echo e($blog->title); ?>" class="pt-5 img-fluid ">
                    </div>
                    
                <?php endif; ?>
                <div>
                    <?php echo $blog->description; ?>

                </div>
                <div class="mt-3">
                    <strong>Tags:</strong> <?php echo e($blog->tag); ?>

                </div>
                <hr>
                <div>
                    <h6>Meta Data</h6>
                    <p><strong>Meta Title:</strong> <?php echo e($blog->meta_title); ?></p>
                    <p><strong>Meta Description:</strong> <?php echo e($blog->meta_description); ?></p>
                    <p><strong>Meta Keyword:</strong> <?php echo e($blog->meta_keyword); ?></p>
                </div>

            </div>
                <div class="card-footer">
                <a href="<?php echo e(route('blogs.index')); ?>" class="btn btn-secondary">Back to Blog List</a>
            </div>
        </div>



    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
        <script>
            document.querySelectorAll('oembed[url]').forEach(element => {
                const url = element.getAttribute('url');
                if (url.includes('youtube.com')) {
                    const videoId = new URL(url).searchParams.get('v');
                    if (videoId) {
                        const iframe = document.createElement('iframe');
                        iframe.setAttribute('src', 'https://www.youtube.com/embed/' + videoId);
                        iframe.setAttribute('frameborder', '0');
                        iframe.setAttribute('allowfullscreen', '1');
                        iframe.style.width = '100%';
                        iframe.style.height = '400px';
                        element.parentNode.replaceChild(iframe, element);
                    }
                }
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/blog/show.blade.php ENDPATH**/ ?>