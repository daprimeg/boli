<?php $__env->startPush('title'); ?> Dashboard <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container-fluid card container-p-y" style="height: 300px; background-image: url(<?php echo e(asset('/public/themeadmin/images/backgrounds/Dots.png')); ?>)">
       

   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>