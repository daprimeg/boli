
<aside id="layout-menu" class="layout-menu menu-vertical menu">

        <span class="menu-button">
            
            <i class="icon-base ti tabler-chevron-right"></i>
        </span>

          <div class="app-brand demo">
            
              <img src="<?php echo e(asset('public/images/logo/logo.png')); ?>" />
            
          </div>

          <div class="menu-inner-shadow"></div>
          <ul class="menu-inner py-1">
           
            <li  class="menu-item">
                <div style="margin: 0px 15px;border-bottom: 1px solid var(--bs-border-color);padding-bottom: 9px;padding-top: 16px;" data-i18n="Menu">Menu </div>
            </li>

            <!-- Dashboards -->
            <li class="menu-item">
              <a href="dashboard" class="menu-link">
                <i class="menu-icon icon-base ti tabler-layout-dashboard"></i>
                <div data-i18n="Dashboard">Dashboard</div>
              </a>
            </li>

           <?php if(Auth::user()->user_type == 1): ?>
        

            <li class="menu-item <?php echo e(request()->is('admin/auctions*') ? 'active' : ''); ?> <?php echo e(request()->is('admin/auctions*') ? 'open' : ''); ?> ">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base ti tabler-database-import"></i>
                <div data-i18n="Data Management">Data Management</div>
              </a>
              <ul class="menu-sub">

                <li class="menu-item <?php echo e(request()->is('admin/auctions*') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.auctions.index')); ?>" class="menu-link">
                    <div data-i18n="Import Data CSV">Import Data CSV</div>
                  </a>
                </li>

                

              </ul>
            </li>

            <li class="menu-item <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?> <?php echo e(request()->is('admin/users*') ? 'open' : ''); ?> ">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base ti tabler-users"></i>
                <div data-i18n="User Management">User Management</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.users.index')); ?>" class="menu-link">
                    <div data-i18n="Manage Users">Manage Users</div>
                  </a>
                </li>
                
                 

              </ul>
            </li>
          

            <li class="menu-item <?php echo e(request()->is('admin/tickets*') ? 'active' : ''); ?> <?php echo e(request()->is('admin/tickets*') ? 'open' : ''); ?>">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base ti tabler-message-report"></i>
                <div data-i18n="Support & Tickets">Support & Tickets</div>
              </a>
              <ul class="menu-sub">

                <li class="menu-item <?php echo e(request()->is('admin/tickets*') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.tickets.index')); ?>" class="menu-link">
                    <div data-i18n="All Support Tickets">All Support Tickets
                    </div>
                  </a>
                </li>
              </ul>
            </li>
        
            <li class="menu-item <?php echo e(request()->is('admin/news*') || request()->is('admin/blogs*') || request()->is('admin/blogcategories*') ? 'active open' : ''); ?> ">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base ti tabler-contract"></i>
                <div data-i18n="Content Management">Content Management</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item <?php echo e(request()->is('admin/blogs*')  ? 'active' : ''); ?> ">
                  <a href="<?php echo e(route('blogs.index')); ?>" class="menu-link">
                    <div data-i18n="Blogs">Blogs</div>
                  </a>
                </li>
                <li class="menu-item <?php echo e(request()->is('admin/blogcategories*')  ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('blogcategories.index')); ?>" class="menu-link">
                    <div data-i18n="Blogs Categories">Blogs Categories</div>
                  </a>
                </li>
                <li class="menu-item <?php echo e(request()->is('admin/news*')  ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.news.index')); ?>" class="menu-link">
                    <div data-i18n="News">News</div>
                  </a>
                </li>
              </ul>
            </li>

            <li class="menu-item <?php echo e(request()->is('admin/memberships*') || request()->is('admin/plans*')  ? 'active open' : ''); ?>">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base ti tabler-calendar-user"></i>
                <div data-i18n="Members & Plans">Members & Plans</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item <?php echo e(request()->is('admin/memberships*') ? 'active open' : ''); ?>">
                  <a href="<?php echo e(route('admin.memberships.index')); ?>" class="menu-link">
                    <div data-i18n="Members">Members</div>
                  </a>
                </li>
                <li class="menu-item <?php echo e(request()->is('admin/plans*') ? 'active open' : ''); ?>">
                  <a href="<?php echo e(route('admin.plans.index')); ?>" class="menu-link">
                    <div data-i18n="Plans">Plans</div>
                  </a>
                </li>
              </ul>
            </li>

            


            <li class="menu-item <?php echo e(request()->is('admin/alerts*') ? 'active open' : ''); ?>">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base ti tabler-alarm-plus"></i>
                <div data-i18n="Notifications">Notifications</div>
              </a>
              <ul class="menu-sub">
                
                <li class="menu-item <?php echo e(request()->is('admin/alerts*') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('alerts.index')); ?>" class="menu-link">
                    <div data-i18n="Alerts">Alerts</div>
                  </a>
                </li>
              </ul>
            </li>

            <?php endif; ?>


            <?php if(Auth::user()->user_type == 0): ?>


      

            <!-- Layouts -->
            <li class="menu-item">
              <a href="<?php echo e(route('auctionfinder')); ?>" class="menu-link">
                <i class="menu-icon icon-base ti tabler-gavel"></i>
                <div data-i18n="Auction Finder">Auction Finder</div>
              </a>
            </li>

            <li class="menu-item">              
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base ti tabler-pointer-heart"></i>
                <div data-i18n="Interest">Interest</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="<?php echo e(route('interest')); ?>" class="menu-link">
                    <div data-i18n="My Interest">My Interest</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="<?php echo e(route('interests.index')); ?>" class="menu-link">
                    <div data-i18n="Create Interest">Create Interest</div>
                  </a>
                </li>
                </ul>
            </li>

            



            

                <!-- Front Pages -->
                <!-- <li class="menu-item">
                  <a href="pinsearch" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-files"></i>
                    <div data-i18n="Pin Search">Pin Search</div>
                  </a>
                </li> -->

                <!-- Apps & Pages -->

                <!-- <li class="menu-item">
                  <a href="todayplan" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-mail"></i>
                    <div data-i18n="Today's Plan">Today's Plan</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="closesearch" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-messages"></i>
                    <div data-i18n="Close Search">Close Search</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="budgetfinder" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-calendar"></i>
                    <div data-i18n="Budget Finder">Budget Finder</div>
                  </a>
                </li>

                <li class="menu-item">
                  <a href="reselltracker" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-layout-kanban"></i>
                    <div data-i18n="Resell Tracker">Resell Tracker</div>
                  </a>
                </li> -->

  
                <!-- Components -->
                

                <li  class="menu-item">
                  <div style="margin: 0px 15px;border-bottom: 1px solid var(--bs-border-color);padding-bottom: 9px;padding-top: 16px;" data-i18n="Profile">Profile </div>
                </li>

                <li class="menu-item">
                  <a href="javascript:void(0);" class="menu-link menu-toggle">
                    <i class="menu-icon icon-base ti tabler-info-hexagon"></i>
                    <div data-i18n="Support">Support</div>
                  </a>
                  <ul class="menu-sub">
                    <li class="menu-item">
                      <a href="<?php echo e(route('ticket.create')); ?>" class="menu-link">
                        <div data-i18n="Create Ticket">Create Ticket</div>
                      </a>
                    </li>
                    <li class="menu-item">
                      <a href="<?php echo e(route('ticket.history')); ?>" class="menu-link">
                        <div data-i18n="Ticket History">Ticket History</div>
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="menu-item">
                  <a href="<?php echo e(route('news.index')); ?>" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-news"></i>
                    <div data-i18n="News">News</div>
                  </a>
                </li>

                <!-- Cards -->
                <li class="menu-item">
                  <a href="<?php echo e(route('profile.userprofile')); ?>" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-id"></i>
                    <div data-i18n="Your Profile">Your Profile</div>
                  </a>
                </li>
                
                <li class="menu-item">
                  <a href="<?php echo e(route('profile.edit')); ?>" class="menu-link">
                    <i class="menu-icon icon-base ti tabler-settings"></i>
                    <div data-i18n="Setting">Setting</div>
                  </a>
                </li>

                <?php endif; ?>

          </ul>
        </aside>
        
        <div class="menu-mobile-toggler d-xl-none rounded-1">
          <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large text-bg-secondary p-2 rounded-1">
            <i class="ti tabler-menu icon-base"></i>
            <i class="ti tabler-chevron-right icon-base"></i>
          </a>
        </div>
     <?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/partial/menu.blade.php ENDPATH**/ ?>