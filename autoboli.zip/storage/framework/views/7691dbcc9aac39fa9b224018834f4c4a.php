
<?php $__env->startPush('title'); ?> VehicleType <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>
<style>

   .form-label{
         padding-top: 18px;
         padding-bottom: 6px;
         font-size: 15px;
   }
   
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid container-p-y">
    <div class="row g-6"> 
        <div class="col-md-12">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header border-bottom">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="card-title">Edit VehicleType</h5>
                        </div>
                        <div class="col-md-6 text-end">
                                <a href="<?php echo e(URL::to('/admin/masters/vehicletypes')); ?>" class="btn btn-primary">Back To List</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/admin/masters/vehicletypes/'.$model->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name',$model->name)); ?>" required />
                                </div>
                            </div>
                        </div>

                        <div class="text-center pt-4" >
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/masters/vehicletypes/edit.blade.php ENDPATH**/ ?>