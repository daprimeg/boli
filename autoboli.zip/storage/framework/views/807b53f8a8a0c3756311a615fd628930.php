<style> 
.circle-checkbox {
  display: flex;
  align-items: center;
  position: relative;
  padding-left: 28px;
  margin-bottom: 10px;
  font-size: 14px;
  color: white;
  cursor: pointer;
}

.circle-checkbox input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

.circle-checkbox .circle {
  position: absolute;
  left: 0;
  top: 2px;
  width: 16px;
  height: 16px;
  background-color: transparent;
  border: 2px solid var(--bs-border-color) !important; /* default border */
  border-radius: 6px; /* lightly rounded box */
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* inner dot when checked */
.circle-checkbox input:checked + .circle::after {
  content: "";
  width: 8px;
  height: 8px;
  background-color: #0d6efd;
  border-radius: 50%;
}

/* if checked, change outer border */
.circle-checkbox input:checked + .circle {
  border-color: #0d6efd;
}

/* disabled style */
.circle-checkbox.disabled {
  color: #6c757d;
  cursor: not-allowed;
}


</style>
<div class="p-4">
    <div class="row"  style="padding: 2px 18px; border-radius: 10px;  !important; margin: 20px 10px">

        
        <div class="col-7"  style=" border-radius: 10px; background-color: var(--bs-navbar-bg) !important; border: 2px solid #192534">
            <div class="p-3  rounded" style="background-color: var(--bs-navbar-bg)">
                
        <div  style="display: flex; justify-content:space-between; align-items: center">
            <div>

                <h2 class="text-xl font-bold">Trad history</h2>
            </div>
            
            <div class="flex gap-2 text-sm">
            <form method="GET" action="<?php echo e(URL::to('/vehicles/index')); ?>">


               <div class="row">
                    <!-- Data Dropdown (left) -->
                    <div class="col-5">
                        <div class="form-group">

                            <!-- Dropdown -->
                        <div class="dropdown">
                        <button class="btn dropdown-toggle px-2 py-1" type="button" id="auctionDropdown" data-bs-toggle="dropdown" aria-expanded="false" style="background:#0f1c2c; border: 1px solid var(--bs-border-color)">
                            Compare Auction
                        </button>

                        <ul class="dropdown-menu dropdown-menu-dark p-2" style="min-width: 200px; background-color: #0f1c2c ;border: 1px solid var(--bs-border-color); border-radius: 8px; 
                       border: 1px solid var(--bs-border-color) ;">
                        <li>
                            <label class="circle-checkbox">
                            <input type="checkbox" checked>
                            <span class="circle"></span>
                            BCA
                            </label>
                        </li>
                        <li>
                            <label class="circle-checkbox ">
                            <input type="checkbox" disabled>
                            <span class="circle"></span>
                            Manheim
                            </label>
                        </li>
                        <li>
                            <label class="circle-checkbox">
                            <input type="checkbox" checked>
                            <span class="circle"></span>
                            CCA
                            </label>
                        </li>
                        <li>
                            <label class="circle-checkbox">
                            <input type="checkbox">
                            <span class="circle"></span>
                            MAG
                            </label>
                        </li>
                        </ul>


                        </div>



                            
                        </div>
                    </div>

                    <!-- Platform Dropdown (right) -->
                    <div class="col-2 ml-2 ">
                        <div class="form-group">

                               <div class="dropdown">
                        <button class="btn  dropdown-toggle px-2 py-1"  type="button" id="auctionDropdown" data-bs-toggle="dropdown" aria-expanded="false" style="background: #0f1c2c; border: 1px solid var(--bs-border-color)">
                            Compare Auction
                        </button>

                        <ul class="dropdown-menu dropdown-menu-dark p-2" style="min-width: 200px; background-color: #0f1c2c; border-radius: 8px; border: 1px solid var(--bs-border-color)">
                        <li>
                            <label class="circle-checkbox">
                            <input type="checkbox" checked>
                            <span class="circle"></span>
                            BCA
                            </label>
                        </li>
                        <li>
                            <label class="circle-checkbox ">
                            <input type="checkbox" >
                            <span class="circle"></span>
                            Manheim
                            </label>
                        </li>
                        <li>
                            <label class="circle-checkbox">
                            <input type="checkbox" checked>
                            <span class="circle"></span>
                            CCA
                            </label>
                        </li>
                        <li>
                            <label class="circle-checkbox">
                            <input type="checkbox">
                            <span class="circle"></span>
                            MAG
                            </label>
                        </li>
                        </ul>


                        </div>
                            
                        </div>
                    </div>
                            
                </div>
            </form>
            </div>
        </div>
        <hr style="border-color: #0f1c2c;">

        
        <div>
            
            <div id="charts" class="my-0 mx-0 " style="width: 100% !important"></div>


        </div>

        
        <div class="row align-items-center" style="border-top: 1px solid #192534">
            <div class="col-md-4 d-flex align-items-center " style="margin-right: -20px">
                <!-- Left content -->
                        <div class="row align-items-center ">
                            
                            <div class="col-auto">
                                <h4 class="mb-0" style="font-weight: 600 ;margin-top: 20px;  margin-bottom: -13px !important;">Autoboli Prediction</h4>
                            </div>
                            <div class="d-flex mt-3 align-items-center">
                                
                                <div class="">
                                    <img src="<?php echo e(asset('public/themeadmin/images/logo/smalllogo.png')); ?>"  style="height: 40px; margin-right: 12px" alt="Logo">
                                </div>

                                
                                <div class="">
                                    <div class="bg-white rounded">
                                        <h5  style="color: black; padding: 6px 46px !important;  margin-top: 12px; ">£13,000</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
            </div>  
            <!-- Vertical Line -->
    <div class="col-4 mt-3"  style="border-left: 1px solid #192534; margin-right: 20px">
        <!-- Right content -->
        <p class="text-sm text-gray-300 max-w-lg leading-snug pt-5" >
                Our price estimates use historical auction data and market trends to suggest likely values. These predictions are informational only and not guarantees of future sale prices.
                <a href="#" class="underline text-blue-300">learn more</a>
            </p>
    </div>
</div>
            </div>
            </div>

            
                <div class="col-5" style="padding: 3px 18px;">
                    <div class="p-3  rounded text-white"  style="background-color: var(--bs-navbar-bg)">
                    <div class="p-3 rounded text-white"  style="background-color: var(--bs-navbar-bg)">
                    <div style="width: 100%; height: 350px; background-color: #000; overflow: hidden; border-radius: 10px; margin-bottom: 30px;">
                        <img 
                            src="<?php echo e($vehicle->getImages()[0]); ?>" 
                            id="mainImage" 
                            class="rounded" 
                             style="width: 100%; height: 100%; object-fit: cover !important; " 
                            alt="Vehicle Main Image"
                            data-bs-toggle="modal" 
                            data-bs-target="#imageModal"
                        >
                        </div>
                    
                    
            
            
                    <div class="d-flex flex-wrap justify-content-left gap-2">                                
                    <!-- Thumbnail Slider -->
                    <div class="swiper mySwiper" style="width: 100%; overflow: hidden;">
                        <div class="swiper-wrapper" style="display: flex; margin-bottom: 33px;">
                        <?php $__currentLoopData = $vehicle->getImages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide" style="flex-shrink: 0; width: auto; ">
                            <img 
                                src="<?php echo e($item); ?>" 
                                class="img-thumbnail"
                                style="cursor: pointer; width: 100px; height: 60px; border-radius: 20%; object-fit:cover !important;"
                                onclick="setMainImage('<?php echo e($item); ?>')"
                            >
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    </div>
                        <div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true" >
                            <div class="modal-dialog modal-dialog-centered modal-xl">
                                <div class="modal-content bg-white border-0 rounded">
                                    <div class="modal-body p-0">
                                        <img id="modalImage" src="" class="img-fluid rounded w-100" style="object-fit: contain !important; max-height: 90vh;">
                                    </div>
                                </div>
                            </div>
                        </div>


                        <span style="font-size: 28px; font-weight: 600; margin: 10px 0px;"><?php echo e($vehicle->year); ?> <?php echo e($vehicle->make->name); ?> <?php echo e($vehicle->model->name); ?> – <?php echo e($vehicle->variant->name); ?></span>
                            <div class="row mt-2  d-flex justify-content-center align-items-center" style="border-radius: 10px; margin-top: 30px !important; background: #00264d !important;padding-top: 10px">
                                <div class="col-md-4" >
                                    <ul style="list-style: none; padding-left: 0px; font-size: 15px;">
                                        <li>
                                            <span style="color: #d4d4d4;">platform</span><br>
                                            <li class="d-flex align-items-center mb-2">
                                            <span style="font-size: 14px"><?php echo e($vehicle->auction->platform->name); ?></span>

                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-4" >
                                    <ul style="list-style: none; padding-left: 0px; padding:px; font-size: 15px;">
                                        <li>
                                            <span style="color: #d4d4d4;">Autions</span><br>
                                        <span class="disc"><?php echo e(\Carbon\Carbon::parse($vehicle->auction->auction_date)->format('Y-m-d')); ?></span>
                                            
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-4">
                                    <ul style="list-style: none; padding-left: 0px; font-size: 15px;">
                                        <li>
                                            <span style="color: #d4d4d4;">Inpaction</span><br>
                                            <button style="padding: 4px 10px; background: #0d6efd;  border-radius: 4px"> View Report</button>
                                        </li>
                                    </ul>
                                </div>
                                

                                </div>
                            </div>
                
            
                </div>
            </div>

    </div>

            
    <div class="row text-start mb-4" style="padding: 40px; background-color: #0c192a">
    <?php
        $fields = [
            ['label' => 'CAP New', 'value' => $vehicle->cap_new],
            ['label' => 'CAP Retail', 'value' => $vehicle->cap_ratail],
            ['label' => 'CAP Clean', 'value' => $vehicle->cap_clean],
            ['label' => 'CAP Average', 'value' => $vehicle->cap_average],
            ['label' => 'CAP Below', 'value' => $vehicle->cap_below ],
        ];
    ?>

    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            
            <div style="display: flex; align-items: center;">
                <div class="dotstats-box"><div class="dotstats" style="  border: 8px solid #0a2e55 !important;"></div></div>
                    <div>
                        <div style="color: white;"><?php echo e($field['value']); ?></div>
                        <div style="color: #ccc; font-size: 15px;"><?php echo e($field['label']); ?></div>
                    </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



   


            

<div class="row" style=" margin: 0px 70px">
    
    <div class="col-md-8 sider">
        <h4>Bidding History</h4>
        <hr style="border-color: #44485e;">
<div class="row">
    <div class="col-md-2 sider1">
        Last Bid<br>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="last_bid" id="last_bid" onclick="return false;">
            <label class="form-check-label disc" for="last_bid"><?php echo e($vehicle->last_bid); ?></label>
        </div>
    </div>
    <div class="col-md-2 sider1">
        Bidding Status<br>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="bidding_status" id="bidding_status" onclick="return false;">
            <label class="form-check-label disc" for="bidding_status"><?php echo e($vehicle->bidding_status); ?></label>
        </div>
    </div>
    <div class="col-md-2 sider1">
        Bidding History<br>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="bidding_history" id="bidding_history" onclick="return false;">
<?php if(!empty($biddingHistoryArray)): ?>
    <ul class="list-disc ps-4">
        <?php $__currentLoopData = $biddingHistoryArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="text-white"><?php echo e($item); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php else: ?>
    <p class="text-muted">No bidding history available.</p>
<?php endif; ?>        </div>
    </div>
    
</div>

             

                    
            

        
        
    </div>

    
    <div class="col-md-4" >
        <div class="border rounded sider p-3" style="background-color: #3f1623 !important; margin-top: 20px">
            <h4>Reauction Track </h4>
            <div class="row">
                <!-- Column 1 -->
                <div class="col-md-6">

                    <ul class="service-list">
                        <div class="service-title">Previous Auction Date</div>
                        <li class="d-flex align-items-center mb-2">
                            <div class="s"><div class="dot"></div></div>4/5/205
                            <span class="disc"><?php echo e($vehicle->service_history); ?></span>
                        </li>
                    </ul>

                    <ul class="service-list">
                        <div class="service-title">Bidding Status</div>
                        <li class="d-flex align-items-center mb-2">
                            <div class="s"><div class="dot"></div></div>
                            <span class="disc"><?php echo e($vehicle->bidding_status); ?></span>
                        </li>
                    </ul>


                </div>
                <!-- Column 2 -->
                <div class="col-md-6">

                    <ul class="service-list">
                        <div class="service-title">Platform</div>
                        <li class="d-flex align-items-center mb-2">
                            <div class="s"><div class="dot"></div></div>
                            <span class="disc"><?php echo e($vehicle->auction->platform->name); ?></span>
                        </li>
                    </ul>

                    <ul class="service-list">
                        <div class="service-title">Last Bid</div>
                        <li class="d-flex align-items-center mb-2">
                            <div class="s"><div class="dot"></div></div>
                            <span class="disc"><?php echo e($vehicle->last_bid); ?></span>
                        </li>
                    </ul>

                

                </div>

            </div>
        </div>
    </div>
</div>   
        <script>
                    document.addEventListener('DOMContentLoaded', function () {
                    // Initialize Swiper
                    const swiper = new Swiper('.mySwiper', {
                        slidesPerView: 4,
                        spaceBetween: 10,
                        breakpoints: {
                            640: { slidesPerView: 5 },
                            768: { slidesPerView: 6 },
                        }
                    });

                    // Handle click on main image to open modal
                    const mainImage = document.getElementById('mainImage');
                    const modalImage = document.getElementById('modalImage');

                    if (mainImage) {
                        mainImage.addEventListener('click', function () {
                            if (modalImage) {
                                modalImage.src = this.src;
                            }
                        });
                    }

                    // Image array and index for cycling
                    const imageUrls = <?php echo json_encode($vehicle->getImages(), 15, 512) ?>;
                    let currentMainIndex = 0;

                    function cycleMainImage() {
                        currentMainIndex = (currentMainIndex + 1) % imageUrls.length;
                        if (mainImage && modalImage) {
                            mainImage.src = imageUrls[currentMainIndex];
                            modalImage.src = imageUrls[currentMainIndex];
                        }
                    }

                    // Set main image on thumbnail click
                    window.setMainImage = function (src) {
                        if (mainImage && modalImage) {
                            mainImage.src = src;
                            modalImage.src = src;
                        }
                    };
                    });
            </script>
  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/vehicles/show/vehicle_valuation.blade.php ENDPATH**/ ?>