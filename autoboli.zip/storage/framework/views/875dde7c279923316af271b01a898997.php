<?php $__env->startPush('title'); ?> vehicle <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>
<style>

   .form-label{
         padding-top: 18px;
         padding-bottom: 6px;
         font-size: 15px;
   }

   .ck-editor__editable {
        min-height: 300px !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid  vehicle-detail-page">
    <div class="row ">
        
        <div class="col-md-2 filters-sidebar border-end  text-white p-3">
           <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">Filters</h5>
            <a href="<?php echo e(URL::to('/admin/vehicles')); ?>" class="btn btn-outline-secondary">Clear All</a> 
    </div>
            
            <form method="GET" action="<?php echo e(URL::to('/vehicles/index')); ?>">
               <div class="row">
    <!-- Data Dropdown (left) -->
    <div class="col-md-5">
        <div class="form-group">
            <label for="data">Data</label>
            <div class="dropdown w-120">
                <button class="btn btn-secondary dropdown-toggle w-120 text-left" type="button"
                        id="dataDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    Data
                </button>
                <div class="dropdown-menu w-100" aria-labelledby="dataDropdown">
                    <a class="dropdown-item" href="#" data-value="">All</a>
                    <?php $__currentLoopData = $auctionsPlatform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item" href="#" data-value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <input type="hidden" name="data_id" id="data_id">
            </div>
        </div>
    </div>

    <!-- Platform Dropdown (right) -->
    <div class="col-md-3">
        <div class="form-group">
            <label for="platform">Platform</label>
            <div class="dropdown w-50">
                <button class="btn btn-secondary dropdown-toggle w-120 text-left" type="button"
                        id="platformDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                     Platform
                </button>
                <div class="dropdown-menu w-100" aria-labelledby="platformDropdown">
                    <a class="dropdown-item" href="#" data-value="">All</a>
                    <?php $__currentLoopData = $auctionsPlatform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item" href="#" data-value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <input type="hidden" name="platform_id" id="platform_id">
            </div>
        </div>
    </div>
</div>

                
            </form>

            
            <div class="vehicle-list mt-4 ">
               <div class="form-group mt-4">    
                    

    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="vehicle-card">
            
            <button class="btn btn-secondary w-100 dropdown-toggle text-start mb-2"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#vehicle-<?php echo e($v->id); ?>"
                    aria-controls="vehicle-<?php echo e($v->id); ?>">
                <strong><?php echo e(strtoupper($v->make->name)); ?></strong><br>
                <?php echo e($v->model->name); ?> <?php echo e($v->year); ?>

            </button>

            
            <div class="collapse" id="vehicle-<?php echo e($v->id); ?>">
                <div class="mt-2">
                    
                    <div class="mb-2">
                        <span class="pickup-badge">BCA</span>
                        <span class="ms-2"><?php echo e(date('j/n/Y_H:i', strtotime($v->pickup_at ?? now()))); ?></span>
                    </div>

                    
              
                        <img src="<?php echo e(asset('public\images\tabs\dashboard.png')); ?>" alt="Vehicle Image" style=" width: 100%;height: 100%;object-fit: cover;" class="vehicle-image  mb-2">

                    
                    
                    <p class="mb-0"><strong>Color:</strong> <?php echo e($colors->name ?? 'N/A'); ?> </p>
                    <p><strong>Plate Number:</strong> <?php echo e($v->plate_number ?? 'N/A'); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


            </div>
        </div>

        
        <div class="col-md-9 p-4">
      <div class="col-md-12 p-4">
    <div class="row">
        
        <div class="col-md-6">
           
                        
                        <img 
                            src="<?php echo e(asset('public\images\tabs\dashboard.png')); ?>" 
                            id="mainImage" 
                            class="img-fluid rounded border mb-3 w-100" 
                            style="height: 400px;  object-fit: cover; cursor: pointer;" 
                            alt="Vehicle Main Image"
                            data-bs-toggle="modal" 
                            data-bs-target="#imageModal"
                        >

                        
                        <div class="d-flex flex-wrap justify-content-left gap-2">
                            <img 
                                src="<?php echo e(asset('public\images\tabs\dashboard.png')); ?>" 
                                class="img-thumbnail" 
                                style="cursor:pointer; width: 80px; border-radius: 20%; height: 80px; object-fit: cover;" 
                                onclick="changeMainImage(this.src)"
                            >
                            <img 
                                src="<?php echo e(asset('public\images\tabs\dashboard.png')); ?>" 
                                class="img-thumbnail" 
                                style="cursor:pointer; width: 80px; height: 80px; object-fit: cover; border-radius: 20%;" 
                                onclick="changeMainImage(this.src)"
                            >
                            <img 
                                src="<?php echo e(asset('public\images\backgrounds\information.png')); ?>" 
                                class="img-thumbnail" 
                                style="cursor:pointer; width: 80px; height: 80px; object-fit: cover; border-radius: 20%;" 
                                onclick="changeMainImage(this.src)"
                            >
                            <img 
                                src="<?php echo e(asset('public\images\backgrounds\information.png')); ?>" 
                                class="img-thumbnail" 
                                style="cursor:pointer; width: 80px; height: 80px; object-fit: cover; border-radius: 20%;" 
                                onclick="changeMainImage(this.src)"
                            >
                            <img 
                                src="<?php echo e(asset('public\images\backgrounds\information.png')); ?>" 
                                class="img-thumbnail" 
                                style="cursor:pointer; width: 80px; height: 80px; object-fit: cover; border-radius: 20%;" 
                                onclick="changeMainImage(this.src)"
                            >
                            <img 
                                src="<?php echo e(asset('public\images\backgrounds\information.png')); ?>" 
                                class="img-thumbnail" 
                                style="cursor:pointer; width: 80px; height: 80px; object-fit: cover; border-radius: 20%;" 
                                onclick="changeMainImage(this.src)"
                            >
                        </div>
                        
                        
                        <div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-xl">
                                <div class="modal-content bg-white border-0 rounded">
                                    <div class="modal-body p-0">
                                        <img id="modalImage" src="" class="img-fluid rounded w-100" style="object-fit: contain; max-height: 90vh;">
                                    </div>
                                </div>
                            </div>
                        </div>

                  
                </div>

            <script>
                document.getElementById('mainImage')?.addEventListener('click', function () {
                    document.getElementById('modalImage').src = this.src;
                });

                function changeMainImage(src) {
                    document.getElementById('mainImage').src = src;
                    document.getElementById('modalImage').src = src;
                }
            </script>

        
        
        <div class="col-md-6">
            <h3><?php echo e($vehicle->year); ?> <?php echo e($vehicle->make->name); ?> <?php echo e($vehicle->model->name); ?> – <?php echo e($vehicle->variant->name); ?></h3>
        <div class="row text-start">
           <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Make</strong><br>
                <?php echo e($vehicle->make->name); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Model</strong><br>
                <?php echo e($vehicle->model->name); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Vareient</strong><br>
                <?php echo e($vehicle->grade); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>year</strong><br>
                <?php echo e($vehicle->year); ?>

            </li>
        </ul>
    </div>
  
    </div>
        <div class="row text-start mb-4">
           <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Platform</strong><br>
                <?php echo e($vehicle->auction->platform->name); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Auction</strong><br>
                <?php echo e($vehicle->auction->auction_date); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Inspaction</strong><br>
                <button class="btn btn-info" onclick="btn">
                view report</button>
            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Inspaction</strong><br>
               <button class="btn btn-info" onclick="btn">
                view report</button>
            </li>
        </ul>
    </div>
    </div>
            
            <div class="accordion mt-3" id="disclaimerAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button bg-danger collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                            Disclaimer
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#disclaimerAccordion">
                        <div class="accordion-body">
                            This vehicle data source is from <?php echo e($vehicle->data_source ?? 'Unknown'); ?>.
                        </div>
                    </div>
                </div>
            </div>
            <div class="accordion mt-3" id="disclaimerAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsetwo">
                            Disclaimer
                        </button>
                    </h2>
                    <div id="collapsetwo" class="accordion-collapse collapse" data-bs-parent="#disclaimerAccordion">
                        <div class="accordion-body">
                            This vehicle data source is from <?php echo e($vehicle->data_source ?? 'Unknown'); ?>.
                        </div>
                    </div>
                </div>
            </div>
            <div class="accordion mt-3" id="disclaimerAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsethree">
                            Disclaimer
                        </button>
                    </h2>
                    <div id="collapsethree" class="accordion-collapse collapse" data-bs-parent="#disclaimerAccordion">
                        <div class="accordion-body">
                            This vehicle data source is from <?php echo e($vehicle->data_source ?? 'Unknown'); ?>.
                        </div>
                    </div>
                </div>
            </div>
            <div class="accordion mt-3" id="disclaimerAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse4">
                            Disclaimer
                        </button>
                    </h2>
                    <div id="collapse4" class="accordion-collapse collapse" data-bs-parent="#disclaimerAccordion">
                        <div class="accordion-body">
                            This vehicle data source is from <?php echo e($vehicle->data_source ?? 'Unknown'); ?>.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



 





            
    <div class="row text-start mb-4">
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Reg</strong><br>
                <?php echo e($vehicle->reg); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>DOR</strong><br>
                <?php echo e($vehicle->dor); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Mileage</strong><br>
                <?php echo e($vehicle->mileage); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong>Grade</strong><br>
                <?php echo e($vehicle->grade); ?>

            </li>
        </ul>
    </div>
    <div class="col">
        <ul style="list-style: square; padding-left: 1.2rem;">
            <li>
                <strong> Present V5</strong><br>
               <?php echo e($vehicle->v5_status ? 'Present' : 'Not Present'); ?>

            </li>
        </ul>
    </div>
</div>

<div class="row">
    
    <div class="col-md-8">
        
        <h4>Overview</h4>
        <hr style="border-color: #44485e;">
        <div class="row">
            <div class="col-md-3"><strong>Make:</strong> <?php echo e($vehicle->vehicle_id); ?></div>
            <div class="col-md-3"><strong>Make:</strong> <?php echo e($vehicle->make->name); ?></div>
            <div class="col-md-3"><strong>Model:</strong> <?php echo e($vehicle->model->name); ?></div>
            <div class="col-md-3"><strong>Variant:</strong> <?php echo e($vehicle->variant->name); ?></div>
            <div class="col-md-3"><strong>CC:</strong> <?php echo e($vehicle->cc); ?></div>
            <div class="col-md-3"><strong>Year:</strong> <?php echo e($vehicle->year); ?></div>
            <div class="col-md-3"><strong>Body Type:</strong> <?php echo e($vehicle->body_id); ?></div>
            <div class="col-md-3"><strong>Color:</strong> <?php echo e($vehicle->color_id); ?></div>
            <div class="col-md-3"><strong>Fuel Type:</strong> <?php echo e($vehicle->fuel_type); ?></div>
            <div class="col-md-3"><strong>Transmission:</strong> <?php echo e($vehicle->transmission); ?></div>
            <div class="col-md-3"><strong>Keys:</strong> <?php echo e($vehicle->keys); ?></div>
            <div class="col-md-3"><strong>Doors:</strong> <?php echo e($vehicle->doors); ?></div>
            <div class="col-md-3"><strong>Seats:</strong> <?php echo e($vehicle->seats); ?></div>
        </div>

        
        <h4 class="mt-4">Additional Information</h4>
        <hr style="border-color: #44485e;">
        <div class="row">
            <div class="col-md-3"><strong>Former Keepers:</strong> <?php echo e($vehicle->former_keepers); ?></div>
            <div class="col-md-3"><strong>Vendor:</strong> <?php echo e($vehicle->vendor); ?></div>
            <div class="col-md-3"><strong>Registration Date:</strong> <?php echo e($vehicle->Registration); ?></div>
            <div class="col-md-3"><strong>VAT Type:</strong> <?php echo e($vehicle->vat_type); ?></div>
            <div class="col-md-3"><strong>Euro Status:</strong> <?php echo e($vehicle->euro_status); ?></div>
            <div class="col-md-3"><strong>Engine Runs:</strong> <?php echo e($vehicle->engine_runs); ?></div>
        </div>

        
        <h4 class="mt-4">Features & Equipment</h4>
        <hr style="border-color: #44485e;">
        <div class="row">
            <div class="col-md-12"><strong><?php echo e($vehicle->features); ?></strong></div>
        </div>
    </div>

    
    <div class="col-md-4">
        <div class="border rounded p-3 bg-light">
            <h4>Service History</h4>
            <hr style="border-color: #44485e;">

            <div class="row">
                <!-- Column 1 -->
                <div class="col-md-6">
                    <ul style="list-style: none; padding-left: 0;">
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: blue; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->service_history); ?>

                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: black; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->last_service); ?>

                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: black; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->dvsa_mileage); ?>

                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: black; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->mot_expiry_date); ?>

                        </li>
                    </ul>
                </div>

                <!-- Column 2 -->
                <div class="col-md-6">
                    <ul style="list-style: none; padding-left: 0;">
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: black; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->last_service); ?>

                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: black; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->last_service_mileage); ?>

                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: black; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->service_notes); ?>

                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <div style="border-radius: 70%; background-color: black; margin-right:10px; border:2px solid white; height: 20px; width:20px;"></div>
                            <?php echo e($vehicle->mot_due); ?>

                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    document.querySelectorAll('.dropdown-item').forEach(function(item) {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            let value = this.getAttribute('data-value');
            let text = this.textContent;
            document.getElementById('platform_id').value = value;
            document.getElementById('platformDropdown').textContent = text;
        });
    });
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

    <?php $__env->startSection('js'); ?>
        <script>
            document.querySelectorAll('oembed[url]').forEach(element => {
                const url = element.getAttribute('url');
                if (url.includes('youtube.com')) {
                    const videoId = new URL(url).searchParams.get('v');
                    if (videoId) {
                        const iframe = document.createElement('iframe');
                        iframe.setAttribute('src', 'https://www.youtube.com/embed/' + videoId);
                        iframe.setAttribute('frameborder', '0');
                        iframe.setAttribute('allowfullscreen', '1');
                        iframe.style.width = '100%';
                        iframe.style.height = '400px';
                        element.parentNode.replaceChild(iframe, element);
                    }
                }
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/vehicles/show.blade.php ENDPATH**/ ?>