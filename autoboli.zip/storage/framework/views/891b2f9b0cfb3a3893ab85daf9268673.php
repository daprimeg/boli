  <!-- Vehicle Type Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingVehicleType">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseVehicleType" aria-expanded="false" aria-controls="collapseVehicleType">
                           Vehicle Type
                           </button>
                        </h2>
                        <div id="collapseVehicleType" class="accordion-collapse collapse show" aria-labelledby="headingVehicleType" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $vehicleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="vehicle_types[]" value="<?php echo e($type->id); ?>" id="vehicle_type_<?php echo e($type->id); ?>">
                                    <label class="form-check-label" for="vehicle_type_<?php echo e($type->id); ?>">
                                    <?php echo e($type->name); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($type->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>

                     <!-- Make Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingVehicleType">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseVehiclemake" aria-expanded="false" aria-controls="collapseVehicleType">
                           Make
                           </button>
                        </h2>
                        <div id="collapseVehiclemake" class="accordion-collapse collapse" aria-labelledby="headingVehicleType" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $vehiclemakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="makes[]" value="<?php echo e($type->id); ?>" id="vehicle_type_<?php echo e($type->id); ?>">
                                    <label class="form-check-label" for="vehicle_type_<?php echo e($type->id); ?>">
                                    <?php echo e($type->name); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($type->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>

                     <!-- Model Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingVehicleType">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseVehiclemodel" aria-expanded="false" aria-controls="collapseVehicleType">
                           Model
                           </button>
                        </h2>
                        <div id="collapseVehiclemodel" class="accordion-collapse collapse" aria-labelledby="headingVehicleType" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $vehiclemodels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="models[]" value="<?php echo e($type->id); ?>" id="vehicle_type_<?php echo e($type->id); ?>">
                                    <label class="form-check-label" for="vehicle_type_<?php echo e($type->id); ?>">
                                    <?php echo e($type->name); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($type->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>

                     <!-- Variant Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingVehicleType">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseVehiclevariant" aria-expanded="false" aria-controls="collapseVehicleType">
                           Model Variant
                           </button>
                        </h2>
                        <div id="collapseVehiclevariant" class="accordion-collapse collapse" aria-labelledby="headingVehicleType" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $vehiclevariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="variants[]" value="<?php echo e($type->id); ?>" id="vehicle_type_<?php echo e($type->id); ?>">
                                    <label class="form-check-label" for="vehicle_type_<?php echo e($type->id); ?>">
                                    <?php echo e($type->name); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($type->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>
                     
                     <!-- Years Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingVehicleType">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseVehicleyear" aria-expanded="false" aria-controls="collapseVehicleType">Years
                           </button>
                        </h2>
                        <div id="collapseVehicleyear" class="accordion-collapse collapse" aria-labelledby="headingVehicleType" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $vehicleyears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="years[]" value="<?php echo e($type->id); ?>" id="vehicle_type_<?php echo e($type->id); ?>">
                                    <label class="form-check-label" for="vehicle_type_<?php echo e($type->id); ?>">
                                    <?php echo e($type->year); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($type->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>


                     <!-- Transmission Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingTransmission">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTransmission" aria-expanded="false" aria-controls="collapseTransmission">
                           Transmission
                           </button>
                        </h2>
                        <div id="collapseTransmission" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $transmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="transmission[]" value="<?php echo e($trans->transmission); ?>" id="trans_<?php echo e(Str::slug($trans->transmission)); ?>">
                                    <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->transmission)); ?>">
                                    <?php echo e(ucfirst($trans->transmission)); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>

                     <!-- Fuel type Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingTransmission">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefuel" aria-expanded="false" aria-controls="collapsefuel">
                           Fuel Type
                           </button>
                        </h2>
                        <div id="collapsefuel" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $fuel_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="fuel_type[]" value="<?php echo e($trans->fuel_type); ?>" id="trans_<?php echo e(Str::slug($trans->fuel_type)); ?>">
                                    <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->fuel_type)); ?>">
                                    <?php echo e(ucfirst($trans->fuel_type)); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>

                     <!-- Body type Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingVehicleType">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseVehiclebody" aria-expanded="false" aria-controls="collapseVehiclebody">
                           Body Type
                           </button>
                        </h2>
                        <div id="collapseVehiclebody" class="accordion-collapse collapse" aria-labelledby="headingVehicleType" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $vehiclebodys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="body_types[]" value="<?php echo e($type->id); ?>" id="vehicle_type_<?php echo e($type->id); ?>">
                                    <label class="form-check-label" for="vehicle_type_<?php echo e($type->id); ?>">
                                    <?php echo e($type->name); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($type->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>

                     <!-- Color Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingVehicleType">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseVehiclecolor" aria-expanded="false" aria-controls="collapseVehiclecolor">
                           Color
                           </button>
                        </h2>
                        <div id="collapseVehiclecolor" class="accordion-collapse collapse" aria-labelledby="headingVehicleType" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $vehiclecolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="colors[]" value="<?php echo e($type->id); ?>" id="vehicle_type_<?php echo e($type->id); ?>">
                                    <label class="form-check-label" for="vehicle_type_<?php echo e($type->id); ?>">
                                    <?php echo e($type->name); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($type->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>


                     <!-- Doors Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingTransmission">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapsedoor" aria-expanded="false" aria-controls="collapsedoor">
                           Door
                           </button>
                        </h2>
                        <div id="collapsedoor" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $doors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="doors[]" value="<?php echo e($trans->doors); ?>" id="trans_<?php echo e(Str::slug($trans->doors)); ?>">
                                    <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->doors)); ?>">
                                    <?php echo e(ucfirst($trans->doors)); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>



                     <!-- Seats Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingTransmission">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseseats" aria-expanded="false" aria-controls="collapseseats">
                           Seats
                           </button>
                        </h2>
                        <div id="collapseseats" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="seats[]" value="<?php echo e($trans->seats); ?>" id="trans_<?php echo e(Str::slug($trans->seats)); ?>">
                                    <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->seats)); ?>">
                                    <?php echo e(ucfirst($trans->seats)); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>



                     <!-- Grade Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingTransmission">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapsegrade" aria-expanded="false" aria-controls="collapsegrade">
                           Grade
                           </button>
                        </h2>
                        <div id="collapsegrade" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="grades[]" value="<?php echo e($trans->grade); ?>" id="trans_<?php echo e(Str::slug($trans->grade)); ?>">
                                    <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->grade)); ?>">
                                    <?php echo e(ucfirst($trans->grade)); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>



                     <!-- V5 Filter -->
                     <div class="accordion-item border-bottom">
                        <h2 class="accordion-header" id="headingTransmission">
                           <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapsev5" aria-expanded="false" aria-controls="collapsev5">
                           V5
                           </button>
                        </h2>
                        <div id="collapsev5" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                           <div class="accordion-body py-1">
                              <?php $__currentLoopData = $v5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check d-flex justify-content-between align-items-center">
                                 <div>
                                    <input class="form-check-input me-1" type="checkbox" name="v5[]" value="<?php echo e($trans->v5); ?>" id="trans_<?php echo e(Str::slug($trans->v5)); ?>">
                                    <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->v5)); ?>">
                                    <?php echo e(ucfirst($trans->v5)); ?>

                                    </label>
                                 </div>
                                 <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                     </div>

                     <!-- Engine Size/CC Filter -->
                        <div class="accordion-item border-bottom">
                           <h2 class="accordion-header" id="headingTransmission">
                              <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapsecc" aria-expanded="false" aria-controls="collapsecc">
                              Engine Size
                              </button>
                           </h2>
                           <div id="collapsecc" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                              <div class="accordion-body py-1">
                                 <?php $__currentLoopData = $cc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="form-check d-flex justify-content-between align-items-center">
                                    <div>
                                       <input class="form-check-input me-1" type="checkbox" name="cc[]" value="<?php echo e($trans->cc); ?>" id="trans_<?php echo e(Str::slug($trans->cc)); ?>">
                                       <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->cc)); ?>">
                                       <?php echo e(ucfirst($trans->cc)); ?>

                                       </label>
                                    </div>
                                    <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                                 </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>


                        <!-- Former Keeper Filter -->
                        <div class="accordion-item border-bottom">
                           <h2 class="accordion-header" id="headingTransmission">
                              <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseformer_keepers" aria-expanded="false" aria-controls="collapseformer_keepers">
                              Former Keepers
                              </button>
                           </h2>
                           <div id="collapseformer_keepers" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                              <div class="accordion-body py-1">
                                 <?php $__currentLoopData = $former_keepers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="form-check d-flex justify-content-between align-items-center">
                                    <div>
                                       <input class="form-check-input me-1" type="checkbox" name="former_keepers[]" value="<?php echo e($trans->former_keepers); ?>" id="trans_<?php echo e(Str::slug($trans->former_keepers)); ?>">
                                       <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->former_keepers)); ?>">
                                       <?php echo e(ucfirst($trans->former_keepers)); ?>

                                       </label>
                                    </div>
                                    <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                                 </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>


                        <!-- No Of services Filter -->
                        <div class="accordion-item border-bottom">
                           <h2 class="accordion-header" id="headingTransmission">
                              <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapsenumber_of_services" aria-expanded="false" aria-controls="collapsenumber_of_services">
                              No. of Services
                              </button>
                           </h2>
                           <div id="collapsenumber_of_services" class="accordion-collapse collapse" aria-labelledby="headingTransmission" data-bs-parent="#filterAccordion">
                              <div class="accordion-body py-1">
                                 <?php $__currentLoopData = $number_of_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="form-check d-flex justify-content-between align-items-center">
                                    <div>
                                       <input class="form-check-input me-1" type="checkbox" name="number_of_services[]" value="<?php echo e($trans->no_of_services); ?>" id="trans_<?php echo e(Str::slug($trans->no_of_services)); ?>">
                                       <label class="form-check-label" for="trans_<?php echo e(Str::slug($trans->no_of_services)); ?>">
                                       <?php echo e(ucfirst($trans->no_of_services)); ?>

                                       </label>
                                    </div>
                                    <span class="badge bg-light text-muted"><?php echo e(number_format($trans->total)); ?></span>
                                 </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>

                        <div class="accordion-item ">
                           <h2 class="accordion-header" id="headingMileage">
                              <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMileage" aria-expanded="false" aria-controls="collapseMileage">
                                 Mileage
                              </button>
                           </h2>
                           <div id="collapseMileage" class="accordion-collapse collapse" aria-labelledby="headingMileage" data-bs-parent="#filterAccordion">
                              <div class="accordion-body py-1">
                                 <div class="row">
                                    <div class="col-6">
                                       <select class="form-select" id="mileage_from">
                                          <option value="">From</option>
                                          <option value="0">0</option>
                                          <option value="10000">10,000</option>
                                          <option value="20000">20,000</option>
                                          <option value="30000">30,000</option>
                                          <option value="40000">40,000</option>
                                          <option value="50000">50,000</option>
                                          <option value="60000">60,000</option>
                                          <option value="70000">70,000</option>
                                          <option value="80000">80,000</option>
                                          <option value="90000">90,000</option>
                                          <option value="100000">100,000</option>
                                       </select>
                                    </div>
                                    <div class="col-6">
                                       <select class="form-select" id="mileage_to">
                                          <option value="">To</option>
                                          <option value="10000">10,000</option>
                                          <option value="20000">20,000</option>
                                          <option value="30000">30,000</option>
                                          <option value="40000">40,000</option>
                                          <option value="50000">50,000</option>
                                          <option value="60000">60,000</option>
                                          <option value="70000">70,000</option>
                                          <option value="80000">80,000</option>
                                          <option value="90000">90,000</option>
                                          <option value="100000">100,000</option>
                                          <option value="150000">150,000</option>
                                       </select>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>



                        <!-- Vehicle Age Filter -->
                        
<?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/auctionfinder/sidebar.blade.php ENDPATH**/ ?>