<?php $__env->startPush('title'); ?> Reauction <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
   .dataTables_length{
      display:none!important;
   }

   .table{
    width: 100%!important;
   }

   .dataTables_info{
      /* display: inline!important; */
   }

   .datatables-products th {
      text-align: center;
   }
   .datatables-products td {
      text-align: center;
   }

   .table-responsive {
      overflow-x: auto!important;
      -webkit-overflow-scrolling: touch!important;
   }

 
        .custom-btn {
            background-color: #1e3a8a;
            color: #fff;
            border: none;
            padding: 5px 15px;
            font-size: 14px;
            border-radius: 3px;
        }
        .custom-btn:hover {
            background-color: #1e40af;
        }
        .custom-btn::after {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
            content: "▼";
            font-size: 10px;
        }
        .dropdown-menu {
            background-color: #1e3a8a;
            border: none;
            border-radius: 3px;
        }
        .dropdown-item {
            color: #fff;
            padding: 5px 15px;
        }
        .dropdown-item:hover {
            background-color: #2a2a40;
        }

</style>


<style>
        .stats-card {
            background: #570303;
            padding: 10px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
        }

        .stats-number {
            font-size: 2.5rem;
            font-weight: bold;
            margin: 0;
        }

        .stats-label {
            font-size: 0.9rem;
            opacity: 0.9;
            margin: 0;
        }

        .platform-info {
           
            border-radius: 8px;
            padding: 15px;
            backdrop-filter: blur(10px);
        }


        .platform-details {
            font-size: 0.75rem;
            opacity: 0.8;
            line-height: 1.4;
        }



        .badge-box {
                display: inline-block;
                padding: 4px 10px;
                margin-left: 6px;
                font-size: 14px;
                color: #fff;
                background-color: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 6px;
            }

            .platform-badges {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                overflow: hidden;
                height: 20px;
            }

            .platform-badge {
                padding: 1px 16px;
                border-radius: 8px;
                color: white;
                border: 1px solid #570303;
                transition: all 0.3s ease;
                border-radius: 4px;
                font-size: 10px;
                font-weight: 600;
              
            }
                .platform-badge.active {
                border: 2px solid #570303;
                color: white;
                background-color: #570303;
                box-shadow: 0 0 10px rgba(220, 53, 69, 0.4);
            }

            .platform-badges:hover {
                min-width: auto;
                height: auto;
                overflow: inherit;
                }

                .platefrom_mar{
                    margin-top: 9px;
                }
                @media only screen and (max-width: 576px) {
                  
                    .inner-tag{
                        flex-direction: column;
                        gap: 2px;
                        margin-top: 5px;
                    }
                    .platefrom_mar{
                        margin-top: 0px;
                    }
                 
                }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('user.reauction.topfilters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid container-p-y">
      <div class="row g-6"> 
            <div class="col-md-12">

                 <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                  <?php endif; ?>

                        <div class="card">
                    
                            
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 class="card-title ">Reauction Details</h5>
                            </div>
                                
                        </div>
               
                        <div class="row pt-5">
                            <div class="col-md-8">
                                <select style="max-width:200px;padding:5px;"  name="length" class="">
                                    <option value="10">10</option>
                                    <option value="100">100</option>
                                    <option value="200">200</option>
                                    <option value="500">500</option>
                                </select>
                                <span style="padding-left: 5px" class="pl-2 pageinfo">0</span>
                        </div>


                        <div class="col-md-4 text-end">
                              <div class="container-fluid">
                                    <div class="row custom-nav">
                                        <div class="col-md-4 mt-2">
                                            <div class="nav-item">
                                                <input type="checkbox" id="inprogress_check">
                                                <label for="inprogress_check">Inprogress</label>
                                            </div>

                                        </div>

                                        <div class="col-md-4 text-center">
                                            <input type="text" name="search" class="form-control" placeholder="Search by Reg" />
                                        </div>

                                      <div class="col-md-4 text-end mt-1">
                                            <div class="row custom-dropdown">
                                                <div class="col-md-12">
                                                    <div class="dropdown">
                                                        <button class="custom-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                            Select Interest
                                                        </button>
                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton" id="interestDropdown">
                                                            <li>
                                                                    <a class="dropdown-item" data-id="">
                                                                        Select Interest
                                                                    </a>
                                                                </li>
                                                            <?php $__empty_1 = true; $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li>
                                                                    <a class="dropdown-item" href="#" data-id="<?php echo e($interest->id); ?>">
                                                                        <?php echo e($interest->title); ?>

                                                                    </a>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><span class="dropdown-item text-muted">No interests found</span></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>

                                                    <input type="hidden" id="selected_interest_id" value="">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="pt-5 table-responsive text-nowrap">
                            <table id="blogTable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Vehicle</th>
                                        <th>Reg</th>
                                        <th>Previous</th>
                                        <th>Platform</th>
                                        <th>Center</th>
                                        <th>Last Bid</th>
                                        <th>Status</th>
                                        <th>Difference</th>
                                        <th>Time</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0"></tbody>
                            </table>
                        </div>


                        <?php echo $__env->make('user.reauction.previouspopup', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>  
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
            $(document).ready(function () {
                        let table = $('#blogTable').DataTable({
                                processing: true,
                                ordering:false,
                                serverSide: true,
                                ajax:{
                                    url: "<?php echo e(url('/reauction')); ?>",
                                    data: function (d) {
                                        d.inprogress_check = $('#inprogress_check').is(':checked') ? 1 : 0;
                                        d.interest_id = $('#selected_interest_id').val();
                                    }
                                }
                                
                            
                            });

                            table.on('draw.dt', function () {
                                var info = table.page.info();
                                $('.pageinfo').html(`Showing ${info.start + 1} to ${info.end} of ${info.recordsDisplay} entries`);
                            });

                            $("input[name='search']").on('keyup change', function () {
                                table.search(this.value).draw();
                            });

                            $("select[name='length']").on('change', function () {
                                const length = $(this).val();
                                table.page.len(length).draw();
                            }).trigger('change');
                            $('#inprogress_check').on('change', function () {
                                table.ajax.reload();
                            });
                            $('#interestDropdown').on('click', '.dropdown-item', function (e) {
                                e.preventDefault();
                                const selectedId = $(this).data('id');
                                $('#selected_interest_id').val(selectedId);
                                $('#dropdownMenuButton').text($(this).text()); 
                                table.ajax.reload();
                            });


                    
            
            });
  

               

$(document).on('click', '.PreviousBtnRec', function () {
    let reg = $(this).data('ref'); 
    if (!reg) return;

    $.ajax({
        url: '<?php echo e(route('reauctioninfo')); ?>',
        method: 'POST',
        data: {
            reg: reg,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
            if (response.length === 0) {
                $('#vehicleModalTableBody').html('<tr><td colspan="6">No data found.</td></tr>');
                return;
            }

          
           
           $('.vehicleName').html(
                response[0].name + ' - ' + response[0].variant + ' - ' +
                '<small class="text-danger" style="font-size: 80%;">' + reg + '</small>'
            );

       
            $('#vehicleModalTableBody').empty();
            response.forEach(function(item) {
                let row = `
                    <tr>
                        <td>${item.platform}</td>
                        <td>${item.center}</td>
                        <td>${item.last_bid}</td>
                        <td>${item.status}</td>
                        <td>${item.difference}</td>
                        <td>${item.time}</td>
                    </tr>
                `;
                $('#vehicleModalTableBody').append(row);
            });

            $('#vehicleModal').modal('show');
        },
        error: function () {
            $('#vehicleModalTableBody').html('<tr><td colspan="6">Failed to load data.</td></tr>');
            $('#vehicleModal').modal('show');
        }
    });
});



    const scrollContainer = document.getElementById('scrollableRow');
    const scrollAmount = 250; // pixels

    document.getElementById('scrollLeft').addEventListener('click', () => {
        scrollContainer.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    });

    document.getElementById('scrollRight').addEventListener('click', () => {
        scrollContainer.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    });


    </script>

    <script>
    $(document).ready(function () {
    $.ajax({
        url: '<?php echo e(route('reauction-interest')); ?>',
        method: 'GET',
        dataType: 'json',
        success: function (interests) {
            let html = '';

            interests.forEach(function (interest, index) {
                html += `
                        <div class="col-auto" style="min-width: 250px;">
                            <div class="card h-100" style="border-bottom: 4px solid var(--bs-primary)!important;">
                                <div class="card-body pb-1 text-start">
                                    <div class="d-flex align-items-start mb-2">
                                        <div class="avatar d-flex align-items-start mb-3">
                                            <div class="box" style="height: 30px; width: 30px; background-color: var(--bs-primary); border-radius: 4px; box-shadow: 0px 0px 5px 8px #003164;"></div>
                                        </div>
                                        <h5 class="mb-0 ms-2">
                                            <span class="auction-count" data-primary="${interest.primary_count}" data-secondary="${interest.secondary_count}">
                                                ${interest.primary_count}
                                            </span>
                                        </h5>
                                    </div>
                                    <p class=" text-start">
                                        <span class="total_auctions">${interest.title}</span>
                                    </p>
                                    <p class="mb-0 text-start">
                                        <label class="d-flex align-items-center cursor-pointer mb-0">
                                            <input type="checkbox" class="secondary-toggle me-2">
                                            <small class="text-body-secondary">Include Secondary</small>
                                        </label>
                                    </p>
                                </div>
                            </div>
                        </div>
                    `;

            });

            $('#scrollableRow').html(html);
        },
        error: function (xhr, status, error) {
            console.error('AJAX Error:', error);
            $('#scrollableRow').html('<p class="text-danger">Failed to load interests.</p>');
        }
    });

    $(document).on('change', '.secondary-toggle', function () {
        const $card = $(this).closest('.card-body');
        const $count = $card.find('.auction-count');
        const primary = $count.data('primary');
        const secondary = $count.data('secondary');

        if ($(this).is(':checked')) {
            $count.text(secondary);
        } else {
            $count.text(primary);
        }
    });
});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/reauction/index.blade.php ENDPATH**/ ?>