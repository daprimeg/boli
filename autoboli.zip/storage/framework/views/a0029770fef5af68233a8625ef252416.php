
<?php $__env->startPush('title'); ?> Users <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>

<style>
   .form-label{
         padding-top: 18px;
         padding-bottom: 6px;
         font-size: 15px;
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <div class="container-xxl flex-grow-1 container-p-y">
      <div class="row g-6"> 
            <div class="col-md-12">
                <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
              

                <div class="card">
                    <div class="card-header border-bottom">
                         <h5 class="card-title">Create User</h5>
                    </div>
                    <div class="card-body">
                        <div class=" mt-4">
                            <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                                <label class="form-label" >Company Name</label>
                                                <input type="text" name="companyName" class="form-control" value="<?php echo e(old('companyName')); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Company Address 1</label>
                                            <input type="text" name="companyAddress1" class="form-control" value="<?php echo e(old('companyAddress1')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Company Address 2</label>
                                            <input type="text" name="companyAddress2" class="form-control" value="<?php echo e(old('companyAddress2')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Town/City</label>
                                            <input type="text" name="townCity" class="form-control" value="<?php echo e(old('townCity')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Country</label>
                                            <input type="text" name="country" class="form-control" value="<?php echo e(old('country')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Postcode</label>
                                            <input type="text" name="postcode" class="form-control" value="<?php echo e(old('postcode')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Telephone</label>
                                            <input type="text" name="telephone" class="form-control" value="<?php echo e(old('telephone')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Business Type</label>
                                            <input type="text" name="businessType" class="form-control" value="<?php echo e(old('businessType')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Company Registration</label>
                                            <input type="text" name="companyReg" class="form-control" value="<?php echo e(old('companyReg')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Website</label>
                                            <input type="text" name="website" class="form-control" value="<?php echo e(old('website')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Business Email</label>
                                            <input type="email" name="businessEmail" class="form-control" value="<?php echo e(old('businessEmail')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Motor Trade Insurance</label>
                                            <input type="text" name="motorTradeInsurance" class="form-control" value="<?php echo e(old('motorTradeInsurance')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">VAT Number</label>
                                            <input type="text" name="vatNumber" class="form-control" value="<?php echo e(old('vatNumber')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">First Name</label>
                                            <input type="text" name="firstName" class="form-control" value="<?php echo e(old('firstName')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Surname</label>
                                            <input type="text" name="surname" class="form-control" value="<?php echo e(old('surname')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Title</label>
                                            <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Job Title</label>
                                            <input type="text" name="jobTitle" class="form-control" value="<?php echo e(old('jobTitle')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Phone</label>
                                            <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Personal Email</label>
                                            <input type="email" name="personalEmail" class="form-control" value="<?php echo e(old('personalEmail')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Upload ID</label>
                                            <input type="file" name="uploadID" class="form-control">
                                        
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Motor Trade Proof</label>
                                            <input type="file" name="motorTradeProof" class="form-control">
                                         
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Address Proof</label>
                                            <input type="file" name="addressProof" class="form-control">
                                        
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Avatar</label>
                                            <input type="file" name="avatar" class="form-control">
                                        
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Status</label>
                                            <select name="status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="0">Deactive</option>
                                            </select>
                                        </div>
                                    </div>
                            </div>
                            <div class="card-footer">
                                <div class="text-center pt-5" >
                                    <button type="submit" class="btn btn-primary">Update User</button>
                                </div>
                            </div>
                        </div>    

                    </form>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
   <script>
      $(document).ready(function() {
         
  
      });
   </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/users/create.blade.php ENDPATH**/ ?>