                   <div class="elementor-element elementor-element-5da2f0a e-con-full e-flex e-con e-parent" data-id="5da2f0a" data-element_type="container">
                        <div class="elementor-element elementor-element-a07fc17 elementor-widget elementor-widget-shortcode" data-id="a07fc17" data-element_type="widget" data-widget_type="shortcode.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-shortcode">
                                    <div data-elementor-type="section" data-elementor-id="3314" class="elementor elementor-3314" data-elementor-post-type="elementor_library">
                                        <div class="elementor-element elementor-element-d3f3f25 e-con-full blur e-flex e-con e-parent" data-id="d3f3f25" data-element_type="container">
                                            <div class="elementor-element elementor-element-716ff19 e-flex e-con-boxed e-con e-child" data-id="716ff19" data-element_type="container">
                                                <div class="e-con-inner">
                                                    <div class="elementor-element elementor-element-d1cbd47 e-con-full e-flex e-con e-child" data-id="d1cbd47" data-element_type="container">
                                                        <div class="elementor-element elementor-element-36aa133 e-con-full e-flex e-con e-child" data-id="36aa133" data-element_type="container">
                                                            <div class="elementor-element elementor-element-9fc15e7 elementor-widget elementor-widget-image" data-id="9fc15e7" data-element_type="widget" data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="https://test.autoboli.co.uk">
                                                                    <img decoding="async" src="https://test.autoboli.co.uk/wp-content/uploads/elementor/thumbs/New-qwbm4atg5mom7s795mh7flgrl4eq6kwg6iyrmg9clc.png" title="New" alt="New" loading="lazy" />								</a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-1186f79 elementor-widget elementor-widget-text-editor" data-id="1186f79" data-element_type="widget" data-widget_type="text-editor.default">
                                                                <div class="elementor-widget-container">
                                                                    <p>Gain insights into thousands of vehicle auctions and make smarter bidding decisions. Subscribe to access full auction data across the nation.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-b1c7860 e-con-full e-flex e-con e-child" data-id="b1c7860" data-element_type="container">
                                                            <div class="elementor-element elementor-element-59268c4 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="59268c4" data-element_type="widget" data-widget_type="divider.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-divider">
                                                                        <span class="elementor-divider-separator">
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-ae2ec2c elementor-shape-rounded elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="ae2ec2c" data-element_type="widget" data-widget_type="social-icons.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-social-icons-wrapper elementor-grid">
                                                                        <span class="elementor-grid-item">
                                                                            <a class="elementor-icon elementor-social-icon elementor-social-icon-facebook-f elementor-repeater-item-b657100" target="_blank">
                                                                                <span class="elementor-screen-only">Facebook-f</span>
                                                                                <svg class="e-font-icon-svg e-fab-facebook-f" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </span>
                                                                        <span class="elementor-grid-item">
                                                                            <a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-304f5d4" target="_blank">
                                                                                <span class="elementor-screen-only">Instagram</span>
                                                                                <svg class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </span>
                                                                        <span class="elementor-grid-item">
                                                                            <a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-repeater-item-8aeb0b4" target="_blank">
                                                                                <span class="elementor-screen-only">Linkedin</span>
                                                                                <svg class="e-font-icon-svg e-fab-linkedin" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </span>
                                                                        <span class="elementor-grid-item">
                                                                            <a class="elementor-icon elementor-social-icon elementor-social-icon-x-twitter elementor-repeater-item-e037f1c" target="_blank">
                                                                                <span class="elementor-screen-only">X-twitter</span>
                                                                                <svg class="e-font-icon-svg e-fab-x-twitter" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </span>
                                                                        <span class="elementor-grid-item">
                                                                            <a class="elementor-icon elementor-social-icon elementor-social-icon-pinterest elementor-repeater-item-5c5043d" target="_blank">
                                                                                <span class="elementor-screen-only">Pinterest</span>
                                                                                <svg class="e-font-icon-svg e-fab-pinterest" viewBox="0 0 496 512" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M496 256c0 137-111 248-248 248-25.6 0-50.2-3.9-73.4-11.1 10.1-16.5 25.2-43.5 30.8-65 3-11.6 15.4-59 15.4-59 8.1 15.4 31.7 28.5 56.8 28.5 74.8 0 128.7-68.8 128.7-154.3 0-81.9-66.9-143.2-152.9-143.2-107 0-163.9 71.8-163.9 150.1 0 36.4 19.4 81.7 50.3 96.1 4.7 2.2 7.2 1.2 8.3-3.3.8-3.4 5-20.3 6.9-28.1.6-2.5.3-4.7-1.7-7.1-10.1-12.5-18.3-35.3-18.3-56.6 0-54.7 41.4-107.6 112-107.6 60.9 0 103.6 41.5 103.6 100.9 0 67.1-33.9 113.6-78 113.6-24.3 0-42.6-20.1-36.7-44.8 7-29.5 20.5-61.3 20.5-82.6 0-19-10.2-34.9-31.4-34.9-24.9 0-44.9 25.7-44.9 60.2 0 22 7.4 36.8 7.4 36.8s-24.5 103.8-29 123.2c-5 21.4-3 51.6-.9 71.2C65.4 450.9 0 361.1 0 256 0 119 111 8 248 8s248 111 248 248z"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-6b7e1cd e-con-full e-flex e-con e-child" data-id="6b7e1cd" data-element_type="container">
                                                        <div class="elementor-element elementor-element-1ca3250 elementor-widget elementor-widget-elementskit-heading" data-id="1ca3250" data-element_type="widget" data-widget_type="elementskit-heading.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="ekit-wid-con" >
                                                                    <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                                                        <h2 class="ekit-heading--title elementskit-section-title ">Company</h2>
                                                                        <div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long">
                                                                            <div class="elementskit-border-divider elementskit-style-long"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-4a74cab elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="4a74cab" data-element_type="widget" data-widget_type="icon-list.default">
                                                            <div class="elementor-widget-container">
                                                                <ul class="elementor-icon-list-items">
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/about/">
                                                                        <span class="elementor-icon-list-text">About Us</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/about/what-we-offer/">
                                                                        <span class="elementor-icon-list-text"> What We Offer</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/about/how-it-works/">
                                                                        <span class="elementor-icon-list-text"> How It Works</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/about/faqs/">
                                                                        <span class="elementor-icon-list-text">FAQs</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/help">
                                                                        <span class="elementor-icon-list-text">Support</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/contact/">
                                                                        <span class="elementor-icon-list-text">Contact Us</span>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-adbe7ac e-con-full e-flex e-con e-child" data-id="adbe7ac" data-element_type="container">
                                                        <div class="elementor-element elementor-element-c180ecc elementor-widget elementor-widget-elementskit-heading" data-id="c180ecc" data-element_type="widget" data-widget_type="elementskit-heading.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="ekit-wid-con" >
                                                                    <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                                                        <h2 class="ekit-heading--title elementskit-section-title "> Quick Link</h2>
                                                                        <div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long">
                                                                            <div class="elementskit-border-divider elementskit-style-long"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-b348b00 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="b348b00" data-element_type="widget" data-widget_type="icon-list.default">
                                                            <div class="elementor-widget-container">
                                                                <ul class="elementor-icon-list-items">
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/pricing">
                                                                        <span class="elementor-icon-list-text">Pricing</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/blog">
                                                                        <span class="elementor-icon-list-text">Blog</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/news">
                                                                        <span class="elementor-icon-list-text">News</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <a href="https://test.autoboli.co.uk/auction-finder">
                                                                        <span class="elementor-icon-list-text">Auction Finder</span>
                                                                        </a>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <span class="elementor-icon-list-text">Search Vehicle</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-6f895f6 e-con-full e-flex e-con e-child" data-id="6f895f6" data-element_type="container">
                                                        <div class="elementor-element elementor-element-e603d09 elementor-widget elementor-widget-elementskit-heading" data-id="e603d09" data-element_type="widget" data-widget_type="elementskit-heading.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="ekit-wid-con" >
                                                                    <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                                                        <h2 class="ekit-heading--title elementskit-section-title ">Contact</h2>
                                                                        <div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long">
                                                                            <div class="elementskit-border-divider elementskit-style-long"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-4925843 elementor-widget elementor-widget-elementskit-heading" data-id="4925843" data-element_type="widget" data-widget_type="elementskit-heading.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="ekit-wid-con" >
                                                                    <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                                                        <div class="ekit-heading--title elementskit-section-title "><span><span>AutoBoli</span></span> Ltd</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-f393d9f elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="f393d9f" data-element_type="widget" data-widget_type="icon-list.default">
                                                            <div class="elementor-widget-container">
                                                                <ul class="elementor-icon-list-items">
                                                                    <li class="elementor-icon-list-item">
                                                                        <span class="elementor-icon-list-icon">
                                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fas-registered" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M285.363 207.475c0 18.6-9.831 28.431-28.431 28.431h-29.876v-56.14h23.378c28.668 0 34.929 8.773 34.929 27.709zM504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM363.411 360.414c-46.729-84.825-43.299-78.636-44.702-80.98 23.432-15.172 37.945-42.979 37.945-74.486 0-54.244-31.5-89.252-105.498-89.252h-70.667c-13.255 0-24 10.745-24 24V372c0 13.255 10.745 24 24 24h22.567c13.255 0 24-10.745 24-24v-71.663h25.556l44.129 82.937a24.001 24.001 0 0 0 21.188 12.727h24.464c18.261-.001 29.829-19.591 21.018-35.587z"></path>
                                                                            </svg>
                                                                        </span>
                                                                        <span class="elementor-icon-list-text">15945005</span>
                                                                    </li>
                                                                    <li class="elementor-icon-list-item">
                                                                        <span class="elementor-icon-list-icon">
                                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fas-map-marker-alt" viewBox="0 0 384 512" xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"></path>
                                                                            </svg>
                                                                        </span>
                                                                        <span class="elementor-icon-list-text">128 City Road, London, United Kingdom, EC1V 2NX</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            
                                            <div class="elementor-element elementor-element-81862d9 e-con-full e-flex e-con e-child" data-id="81862d9" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                <div class="elementor-element elementor-element-8ccf115 elementor-widget elementor-widget-text-editor" data-id="8ccf115" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>©2025. <a href="https://test.autoboli.co.uk/">AutoBoli LTD</a>. All Rights Reserved.</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-56d36b9 elementor-icon-list--layout-inline elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="56d36b9" data-element_type="widget" data-widget_type="icon-list.default">
                                                    <div class="elementor-widget-container">
                                                        <ul class="elementor-icon-list-items elementor-inline-items">
                                                            <li class="elementor-icon-list-item elementor-inline-item">
                                                                <a href="https://test.autoboli.co.uk/disclaimer" target="_blank">
                                                                <span class="elementor-icon-list-text">Disclaimer</span>
                                                                </a>
                                                            </li>
                                                            <li class="elementor-icon-list-item elementor-inline-item">
                                                                <a href="https://test.autoboli.co.uk/terms/" target="_blank">
                                                                <span class="elementor-icon-list-text">Terms and Conditions</span>
                                                                </a>
                                                            </li>
                                                            <li class="elementor-icon-list-item elementor-inline-item">
                                                                <a href="https://test.autoboli.co.uk/privacy-policy/" target="_blank">
                                                                <span class="elementor-icon-list-text">Privacy Policy</span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    
                </div>
            </div>
        </div>
        <div class="site-footer">
            <footer class="site-info" aria-label="Site"  itemtype="https://schema.org/WPFooter" itemscope>
                <div class="inside-site-info grid-container">
                    <div class="copyright-bar">
                        <span class="copyright">&copy; 2025 AutoBoli</span> &bull; Built with <a href="https://generatepress.com" itemprop="url">GeneratePress</a>				
                    </div>
                </div>
            </footer>
        </div>
        <script data-cfasync="false" type="text/javascript">
            function arm_open_modal_box_in_nav_menu(menu_id, form_id) {
                                    
            	jQuery(".arm_nav_menu_link_" + form_id).find("." + form_id).trigger("click");
            	return false;
            }
        </script>
        <script id="generate-a11y">!function(){"use strict";if("querySelector"in document&&"addEventListener"in window){var e=document.body;e.addEventListener("mousedown",function(){e.classList.add("using-mouse")}),e.addEventListener("keydown",function(){e.classList.remove("using-mouse")})}}();</script>		
        <div data-elementor-type="popup" data-elementor-id="4225" class="elementor elementor-4225 elementor-location-popup" data-elementor-settings="{&quot;entrance_animation&quot;:&quot;slideInRight&quot;,&quot;exit_animation&quot;:&quot;slideInRight&quot;,&quot;entrance_animation_duration&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;avoid_multiple_popups&quot;:&quot;yes&quot;,&quot;a11y_navigation&quot;:&quot;yes&quot;,&quot;timing&quot;:[]}" data-elementor-post-type="elementor_library">
            <div class="elementor-element elementor-element-1f15a26 e-flex e-con-boxed e-con e-parent" data-id="1f15a26" data-element_type="container">
                <div class="e-con-inner">
                    <div class="elementor-element elementor-element-2a069bd e-con-full e-flex e-con e-child" data-id="2a069bd" data-element_type="container">
                        <div class="elementor-element elementor-element-f7bbc38 e-con-full e-flex e-con e-child" data-id="f7bbc38" data-element_type="container">
                            <div class="elementor-element elementor-element-63f03fb elementor-widget elementor-widget-image" data-id="63f03fb" data-element_type="widget" data-widget_type="image.default">
                                <div class="elementor-widget-container">
                                    <img width="900" height="210" src="https://test.autoboli.co.uk/wp-content/uploads/2024/10/New-1024x239.png" class="attachment-large size-large wp-image-1876" alt="" srcset="https://test.autoboli.co.uk/wp-content/uploads/2024/10/New-1024x239.png 1024w, https://test.autoboli.co.uk/wp-content/uploads/2024/10/New-600x140.png 600w, https://test.autoboli.co.uk/wp-content/uploads/2024/10/New-300x70.png 300w, https://test.autoboli.co.uk/wp-content/uploads/2024/10/New-768x179.png 768w, https://test.autoboli.co.uk/wp-content/uploads/2024/10/New.png 1184w" sizes="(max-width: 900px) 100vw, 900px" />													
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-81fac5f elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="81fac5f" data-element_type="widget" data-widget_type="divider.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-divider">
                                        <span class="elementor-divider-separator">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-1593d10 e-con-full e-flex e-con e-child" data-id="1593d10" data-element_type="container">
                            <div class="elementor-element elementor-element-0000824 elementor-view-stacked elementor-shape-rounded elementor-position-left elementor-mobile-position-left elementor-vertical-align-middle elementor-widget elementor-widget-icon-box" data-id="0000824" data-element_type="widget" data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-icon-box-wrapper">
                                        <div class="elementor-icon-box-icon">
                                            <a href="https://test.autoboli.co.uk/login/" class="elementor-icon elementor-animation-" tabindex="-1">
                                                <svg aria-hidden="true" class="e-font-icon-svg e-fas-user-alt" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M256 288c79.5 0 144-64.5 144-144S335.5 0 256 0 112 64.5 112 144s64.5 144 144 144zm128 32h-55.1c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16H128C57.3 320 0 377.3 0 448v16c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48v-16c0-70.7-57.3-128-128-128z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                        <div class="elementor-icon-box-content">
                                            <div class="elementor-icon-box-title">
                                                <a href="https://test.autoboli.co.uk/login/" >
                                                Log in / Register						</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-ff5ae9e elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="ff5ae9e" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator">
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-78519e9 e-con-full e-flex e-con e-child" data-id="78519e9" data-element_type="container">
                            <div class="elementor-element elementor-element-3231b73 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="3231b73" data-element_type="widget" data-widget_type="icon-list.default">
                                <div class="elementor-widget-container">
                                    <ul class="elementor-icon-list-items">
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/">
                                            <span class="elementor-icon-list-text">Home</span>
                                            </a>
                                        </li>
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/pricing/">
                                            <span class="elementor-icon-list-text">Pricing</span>
                                            </a>
                                        </li>
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/blog/">
                                            <span class="elementor-icon-list-text">blog</span>
                                            </a>
                                        </li>
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/about/">
                                            <span class="elementor-icon-list-text">About</span>
                                            </a>
                                        </li>
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/about/what-we-offer/">
                                            <span class="elementor-icon-list-text">What We Offer</span>
                                            </a>
                                        </li>
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/about/how-it-works/">
                                            <span class="elementor-icon-list-text">How It Works</span>
                                            </a>
                                        </li>
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/about/faqs/">
                                            <span class="elementor-icon-list-text">FAQs</span>
                                            </a>
                                        </li>
                                        <li class="elementor-icon-list-item">
                                            <a href="https://test.autoboli.co.uk/contact/">
                                            <span class="elementor-icon-list-text">Contact Us</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-cd06c2c e-con-full e-flex e-con e-child" data-id="cd06c2c" data-element_type="container">
                        <div class="elementor-element elementor-element-bf431cd elementor-widget elementor-widget-html" data-id="bf431cd" data-element_type="widget" data-widget_type="html.default">
                            <div class="elementor-widget-container">
                                <style>
                                    .dialog-close-button {
                                    padding: 7px;
                                    border-radius: 3px
                                    }
                                    .dialog-lightbox-widget{
                                    }
                                </style>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <link rel='stylesheet' id='elementor-post-1061-css' href='https://test.autoboli.co.uk/wp-content/uploads/elementor/css/post-1061.css?ver=1734615309' media='all' />
        <link rel='stylesheet' id='elementor-post-3129-css' href='https://test.autoboli.co.uk/wp-content/uploads/elementor/css/post-3129.css?ver=1734534921' media='all' />
        <link rel='stylesheet' id='elementor-post-3314-css' href='https://test.autoboli.co.uk/wp-content/uploads/elementor/css/post-3314.css?ver=1734534921' media='all' />
        <link rel='stylesheet' id='widget-social-icons-css' href='https://test.autoboli.co.uk/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.25.4' media='all' />
        <link rel='stylesheet' id='elementor-post-4225-css' href='https://test.autoboli.co.uk/wp-content/uploads/elementor/css/post-4225.css?ver=1734534921' media='all' />
        <link rel='stylesheet' id='widget-icon-box-css' href='https://test.autoboli.co.uk/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css?ver=3.25.4' media='all' />
        <link rel='stylesheet' id='arm_front_css-css' href='https://test.autoboli.co.uk/wp-content/plugins/armember/css/arm_front.css?ver=6.6' media='all' />
        <link rel='stylesheet' id='e-popup-css' href='https://test.autoboli.co.uk/wp-content/plugins/elementor-pro/assets/css/conditionals/popup.min.css?ver=3.25.0' media='all' />



        <script src="https://test.autoboli.co.uk/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=9.3.3" id="sourcebuster-js-js"></script>

        <script src="https://test.autoboli.co.uk/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=9.3.3" id="wc-order-attribution-js"></script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.25.0" id="e-sticky-js"></script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.25.0" id="elementor-pro-webpack-runtime-js"></script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.25.4" id="elementor-webpack-runtime-js"></script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.25.4" id="elementor-frontend-modules-js"></script>
        <script data-cfasync="false" src="https://test.autoboli.co.uk/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
        <script data-cfasync="false" src="https://test.autoboli.co.uk/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>

        <script id="elementor-pro-frontend-js-before">
            var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/test.autoboli.co.uk\/wp-admin\/admin-ajax.php","nonce":"3cb9007525","urls":{"assets":"https:\/\/test.autoboli.co.uk\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/test.autoboli.co.uk\/wp-json\/"},"settings":{"lazy_load_background_images":true},"popup":{"hasPopUps":true},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"},"x-twitter":{"title":"X"},"threads":{"title":"Threads"}},"woocommerce":{"menu_cart":{"cart_page_url":"https:\/\/test.autoboli.co.uk\/?page_id=677","checkout_page_url":"https:\/\/test.autoboli.co.uk\/checkout\/","fragments_nonce":"7e1f32fd03"}},"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/test.autoboli.co.uk\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
        </script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.25.0" id="elementor-pro-frontend-js"></script>
        <script id="elementor-frontend-js-before">
            var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"3.25.4","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"container":true,"e_swiper_latest":true,"e_nested_atomic_repeaters":true,"e_optimized_control_loading":true,"e_onboarding":true,"e_css_smooth_scroll":true,"theme_builder_v2":true,"home_screen":true,"nested-elements":true,"editor_v2":true,"e_element_cache":true,"link-in-bio":true,"floating-buttons":true},"urls":{"assets":"https:\/\/test.autoboli.co.uk\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/test.autoboli.co.uk\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/test.autoboli.co.uk\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"741d27a090"},"swiperClass":"swiper","settings":{"page":[],"editorPreferences":[]},"kit":{"body_background_background":"classic","active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","woocommerce_notices_elements":[]},"post":{"id":24,"title":"Pricing%20%E2%80%93%20AutoBoli","excerpt":"","featuredImage":false}};
        </script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.25.4" id="elementor-frontend-js"></script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.25.0" id="pro-elements-handlers-js"></script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/metform-pro/public/assets/js/repeater.js?ver=3.8.3" id="metform-pro-repeater-js"></script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementskit-lite/widgets/init/assets/js/animate-circle.min.js?ver=3.3.1" id="animate-circle-js"></script>
        <script id="elementskit-elementor-js-extra">
            var ekit_config = {"ajaxurl":"https:\/\/test.autoboli.co.uk\/wp-admin\/admin-ajax.php","nonce":"a8713752a5"};
        </script>
        <script src="https://test.autoboli.co.uk/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor.js?ver=3.3.1" id="elementskit-elementor-js"></script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/partials/foot.blade.php ENDPATH**/ ?>