<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Payment</title>
</head>
<body>
    <h1>Pay £<?php echo e(number_format($amount, 2)); ?></h1>
    <form action="<?php echo e(route('payment.process')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
        <button type="submit">Pay with PayPal</button>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/test_payment_form.blade.php ENDPATH**/ ?>