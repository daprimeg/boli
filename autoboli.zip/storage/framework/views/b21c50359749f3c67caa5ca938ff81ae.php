

<?php $__env->startPush('title'); ?> Ticket <?php $__env->stopPush(); ?>

<?php $__env->startSection('css'); ?>
    

    <style>
        .form-label{
            padding-top: 18px;
            padding-bottom: 6px;
            font-size: 15px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="col-md-12">

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="card">
                      <div class="card-header border-bottom">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="card-title">Create Ticket</h5>
                            </div>
                            <div class="col-md-6 text-end">
                                 <a href="<?php echo e(URL::to('/tickets')); ?>" class="btn btn-primary">Back To List</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                 
                        <form class="pt-4" action="<?php echo e(route('ticket.store')); ?>" method="POST" enctype="multipart/form-data"  id="ticketForm" >
                            <?php echo csrf_field(); ?>
                            <div class="row gy-4 gx-6 mb-6">
                                <div class="col-md-4">
                                    <label for="issuetopic" class="form-label">Select Issue Topic</label>
                                    <select id="issuetopic" name="issue_topic" class="form-select" required>
                                        <option value="">Select</option>
                                        <option value="Data Error / Incorrect Auction Info">Data Error / Incorrect Auction Info</option>
                                        <option value="Can't Find a Vehicle">Can't Find a Vehicle</option>
                                        <option value="Billing or Membership">Billing or Membership</option>
                                        <option value="Login / Account Access">Login / Account Access</option>
                                        <option value="Feature Request / Feedback">Feature Request / Feedback</option>
                                        <option value="Technical Bug / Other">Technical Bug / Other</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label id="detailsLabel" for="detailsInput" class="form-label">More Details</label>
                                    <input id="detailsInput" name="issue_type" class="form-control" type="text" placeholder="Enter details" disabled />
                                </div>
                                <div class="col-md-4">
                                    <label for="priority" class="form-label">Priority</label>
                                    <select id="priority" name="priority" class="form-select" required>
                                        <option value="">Select Priority</option>
                                        <option value="Low">Low</option>
                                        <option value="Medium">Medium</option>
                                        <option value="High">High</option>
                                    </select>
                                </div>

                                <div class="col-md-12">
                                    <h5>Description</h5>
                                    <textarea class="form-control" name="details" id="description" rows="3"></textarea>
                                </div>
                                <div class="mb-4">
                                    <label for="formFileMultiple" class="form-label">Upload Issue</label>
                                    <input class="form-control" type="file" name="attachment" id="formFileMultiple">
                                </div>
                                <div class="mt-2">
                                    <button type="submit" class="btn btn-primary me-3">Submit Ticket</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

 <script src="<?php echo e(asset('public/assets/ckeditor/build/ckeditor.js')); ?>"></script>
 <script>
        ClassicEditor
            .create(document.querySelector('#description'))
            .then(editor => {
                editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
                    return new MyUploadAdapter(loader);
                };
            })
            .catch(error => {
                console.error(error);
            });

        class MyUploadAdapter {
            constructor(loader) {
                this.loader = loader;
            }

            upload() {
                return this.loader.file
                    .then(file => {
                        return new Promise((resolve, reject) => {
                            const data = new FormData();
                            data.append('upload', file);
                            data.append('_token', '<?php echo e(csrf_token()); ?>');

                            fetch("<?php echo e(url('//upload-image')); ?>", {
                                method: 'POST',
                                body: data
                            })
                            .then(response => response.json())
                            .then(result => {
                                if (result.url) {
                                    resolve({
                                        default: result.url
                                    });
                                } else {
                                    reject(result.error || 'Upload failed.');
                                }
                            })
                            .catch(() => {
                                reject('Upload failed.');
                            });
                        });
                    });
            }

            abort() {
        
            }
        }

    </script>
    
        
        <script>
            const issueType = document.getElementById('issuetopic');
            const detailsLabel = document.getElementById('detailsLabel');
            const detailsInput = document.getElementById('detailsInput');
            
            issueType.addEventListener('change', function () {
                const value = this.value;
                detailsInput.style.display = 'block';
                detailsInput.disabled = false;
                
                switch (value) {
                    case 'Data Error / Incorrect Auction Info':
                        detailsLabel.textContent = 'Vehicle Link or ID';
                        break;
                    case "Can't Find a Vehicle":
                        detailsLabel.textContent = 'Vehicle Make/Model';
                        break;
                    case 'Billing or Membership':
                        detailsLabel.textContent = 'Billing Date / Invoice ID';
                        break;
                    case 'Login / Account Access':
                        detailsLabel.textContent = 'Subject';
                        break;
                    case 'Feature Request / Feedback':
                        detailsLabel.textContent = 'Add The Feature Name';
                        break;
                    case 'Technical Bug / Other':
                        detailsLabel.textContent = 'Page URL or Feature Name';
                        break;
                    default:
                        detailsLabel.textContent = 'More Details';
                        detailsInput.disabled = true;
                        break;
                }
            });
            
            
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/ticket/create.blade.php ENDPATH**/ ?>