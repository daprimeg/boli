
<?php $__env->startPush('title'); ?> Auctions <?php $__env->stopPush(); ?> 
<?php $__env->startSection('css'); ?>

<style>
   .form-label{
         padding-top: 18px;
         padding-bottom: 6px;
         font-size: 15px;
   }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
     <div class="row g-6"> 
         <div class="col-md-12">

            <?php if($errors->any()): ?>
               <div class="alert alert-danger">
                  <ul class="mb-0">
                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
               </div>
            <?php endif; ?>

            <div class="card">
                  <div class="card-header border-bottom">
                     <h5 class="card-title">Edit Auction</h5>
                  </div>
                  <div class="card-body">
                     <form class="pt-3" method="POST" action="<?php echo e(route('admin.auctions.update', $auction->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">

                           <div class="col-md-4">
                              <div class="form-group">
                                 <label class="form-label" for="auction_type">Auction Type</label>
                                 <select name="auction_type" id="auction_type" class="form-control" required>
                                    <option value="">-- Select Auction Type --</option>
                                    <option value="Online Auction" 
                                          <?php echo e(old('auction_type', $auction->auction_type) == 'Online Auction' ? 'selected' : ''); ?>>
                                          Online Auction
                                    </option>
                                    <option value="Time Auction" 
                                          <?php echo e(old('auction_type', $auction->auction_type) == 'Time Auction' ? 'selected' : ''); ?>>
                                          Time Auction
                                    </option>
                                 </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                 <label class="form-label" >Name</label>
                                 <input type="text" name="name" value="<?php echo e(old('name', $auction->name)); ?>" class="form-control" required>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group ">
                                 <label class="form-label" for="platform_id">Platform</label>
                                 <select name="platform_id" id="platform_id" class="form-control" required>
                                    <option value="">-- Select Platform --</option>
                                    <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($platform->id); ?>" <?php echo e(old('platform_id', $auction->platform_id) == $platform->id ? 'selected' : ''); ?>

                                          ><?php echo e($platform->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="form-group">
                                 <label class="form-label">Date</label>
                                 <input type="datetime-local" name="auction_date" value="<?php echo e(old('auction_date', $auction->auction_date)); ?>" class="form-control" required>
                              </div>
                           </div>

                           <div class="col-md-4 end_date">
                              <div class="form-group">
                                 <label class="form-label">End Date</label>
                                 <input type="datetime-local" name="end_date" value="<?php echo e(old('end_date', $auction->end_date)); ?>" class="form-control" />
                              </div>
                           </div>

                           <div class="col-md-4">
                              <div class="">
                                 <label class="form-label" for="csv_path">Auction CSV File (optional)</label>
                                 <input type="file" name="csv_path" id="csv_path" class="form-control">
                                 <?php if($auction->csv_path): ?>
                                    <small class="d-block mt-1">
                                       Current File:
                                       <a href="<?php echo e(URL::to('/admin/auctions/viewCsv/'.$auction->id)); ?>" target="_blank">View CSV</a>
                                    </small>
                                 <?php endif; ?>
                              </div>
                           </div>

                        </div>
                        <div class="text-center pt-4" > 
                           <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                     </form>
                  </div>
            </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
      <script>
            document.addEventListener("DOMContentLoaded", function () {

               const platformSelect = document.getElementById('platform_id');

               $('select[name=auction_type]').change(function (e) { 
               
                  if($(this).val() == "Online Auction"){
                        $('.end_date input').val('').prop('required', false);
                        $('.end_date').hide();
                  }else{
                     $('.end_date').show();
                     $('.end_date input').show().prop('required', true);
                  }
                  
               }).trigger('change');


               // const centerSelect = document.getElementById('center_id');
               // const ajaxUrlTemplate = <?php echo json_encode(route('centers.ajax', ':id'), 512) ?>;

               // function fetchCenters(platformId, selectedCenterId = null) {
               //    const ajaxUrl = ajaxUrlTemplate.replace(':id', platformId);
               //    centerSelect.innerHTML = '<option value="">Loading...</option>';

               //    fetch(ajaxUrl)
               //          .then(response => response.json())
               //          .then(data => {
               //             centerSelect.innerHTML = '<option value="">-- Select Center --</option>';
               //             data.forEach(center => {
               //                const option = document.createElement('option');
               //                option.value = center.id;
               //                option.textContent = center.name;
               //                if (selectedCenterId && selectedCenterId == center.id) {
               //                      option.selected = true;
               //                }
               //                centerSelect.appendChild(option);
               //             });
               //          });
               // }

               // platformSelect.addEventListener('change', function () {
               //    const platformId = this.value;
               //    if (platformId) {
               //          fetchCenters(platformId);
               //    } else {
               //          centerSelect.innerHTML = '<option value="">-- Select Center --</option>';
               //    }
               // });

               // Load centers if editing
               // <?php if(old('platform_id', $auction->platform_id)): ?>
                  // fetchCenters("<?php echo e(old('platform_id', $auction->platform_id)); ?>", "<?php echo e(old('center_id', $auction->center_id)); ?>");
               // <?php endif; ?>

            });
      </script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/datamanagement/auctions/edit.blade.php ENDPATH**/ ?>