<?php $__env->startPush('title'); ?>
    News
<?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>
    <style>
      

        .news-list {
            width: 20%;
            border-right: 1px solid var(--bs-b-color)!important;
            padding-right: 20px;
          
            overflow-y: auto;
            /* padding-left: 50px; */
            padding: 0;

        }

        .news-detail {
            width: 80%;
            padding: 30px
        }
        .hover-news > div:hover {
        background-color: #001020;
        cursor: pointer;
    }
    {
         background-color: #001020;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            
            
                <div class="d-flex "  style="background: #0f1c2d; height: 100%; !important ; ">
                    
                    <div class="news-list col-4 hover-news" >
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3 border-bottom "style="padding: 20px; text-align-center  ">
                                <h6 style="font-size: 18px; font-weight: 500; cursor: pointer;" onclick="showNews(<?php echo e($item->id); ?>)">
                                    <?php echo e($item->title); ?>

                                </h6>
                                <small class="text-muted"><span
                                        style="background-color: #00316b; color: white;padding:4px 12px; border-radius: 4px; font-size: 12px;">Category</span> <?php echo e($item->date); ?></small>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    
                    <div class="news-detail col-7 ">

                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="news-<?php echo e($item->id); ?>" class="news-full-content "
                                style="display: none; background-color: #001020;  color: #ffffff; padding: 50px; border-radius: 8px; margin-bottom: 24px; font-family: Arial, sans-serif;">
                                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                                    <span
                                        style="background-color: #00316b; color: white; padding:4px 12px; border-radius: 4px; font-size: 12px; margin-right: 12px;">Category</span>
                                    <span style="color: #c9d1d9; font-size: 14px;"> <?php echo e($item->date); ?></span>
                                </div>
                                <div class="row">

                                    <div class="col-8" style = "border-bottom: 2px solid var(--bs-b-color)!important; margin-right: 15px;">
                                        <div class="d-flex flex-column justify-content-between h-100">

                                        <h4 style=" ">
                                            <?php echo e($item->title); ?>

                                        </h4>
                                        <div
                                            style="display: flex; gap: 450px; center; margin-bottom: 10px;">
                                            <div style="font-size: 14px; color: #c9d1d9;">Like: 12<br>Author Name</div>
                                            <div style="display: flex; gap: 10px; margin-right: 110px; margin-top: 20px;">
                                                share
                                                <div style="width: 18px; height: 18px; background-color: #3084ff;"></div>
                                                <div style="width: 18px; height: 18px; background-color: #3084ff;"></div>
                                                <div style="width: 18px; height: 18px; background-color: #3084ff;"></div>
                                            </div>
                                        </div>
                                        </div>

                                    </div>


                                    
                                    <div class="col-4" style="background: #d1d5db00; height: 220px; width: 320px;">
                                        <img src="<?php echo e(asset('/public/theme/assets/largecar.jpg')); ?>"
                                        style="height: 100%; width: 100%; object-fit: cover">
                                    </div>
                                </div>



                                <p style="line-height: 1.7; color: #d1d5db;margin-top: 30px;"><?php echo $item->description; ?></p>

                                <form action="<?php echo e(route('news.togglePin', $item->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex align-items-center gap-3" style="margin-top: 20px;">
                                        <button
                                            class="btn btn-sm <?php echo e($user->pinnedNews->contains($item->id) ? 'btn-danger' : 'btn-outline-primary'); ?>"
                                            style="padding: 6px 14px; font-size: 14px; border-radius: 4px;">
                                            <?php echo e($user->pinnedNews->contains($item->id) ? 'Unpin' : 'Pin'); ?>

                                        </button>

                                    </div>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div id="news-placeholder" class="text-muted">
                            <p>Click a news item to view details here...</p>
                        </div>
                    </div>
                </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function showNews(id) {
            document.querySelectorAll('.news-full-content').forEach(el => el.style.display = 'none');
            document.getElementById('news-placeholder').style.display = 'none';
            const selected = document.getElementById('news-' + id);
            if (selected) selected.style.display = 'block';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/news.blade.php ENDPATH**/ ?>