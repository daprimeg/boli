<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <label class="form-label" >Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $blog->title ?? '')); ?>">
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="form-label">Slug</label>
            <input type="text" name="slug" class="form-control" value="<?php echo e(old('slug', $blog->slug ?? '')); ?>">
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="form-label">Image</label>
            <input type="file" name="image" class="form-control">
            <?php if(isset($blog) && $blog->image): ?>
                <a href="<?php echo e(asset('/public/uploads/blogs/'.$blog->image)); ?>" target="_blank">
                    <img class="pt-2" style="width: 50px;" src="<?php echo e(asset('/public/uploads/blogs/'.$blog->image)); ?>" />
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group">
            <label class="form-label">Description</label>
                <textarea id="description" name="description" class="form-control" rows="10"><?php echo e(old('description', $blog->description ?? '')); ?></textarea>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
                <label class="form-label">Date</label>
                <input type="date" name="date" class="form-control" value="<?php echo e(old('date', $blog->date ?? '')); ?>">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-control">
                <option value="">-- Select --</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e((old('category_id', $blog->category_id ?? '') == $category->id) ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="form-label">Tag</label>
            <input type="text" name="tag" class="form-control" value="<?php echo e(old('tag', $blog->tag ?? '')); ?>">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
                <option value="1" <?php echo e(old('status', $blog->status ?? '') == 1 ? 'selected' : ''); ?>>Active</option>
                <option value="0" <?php echo e(old('status', $blog->status ?? '') == 0 ? 'selected' : ''); ?>>Inactive</option>
            </select>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="form-label">Meta Title</label>
            <input type="text" name="meta_title" class="form-control" value="<?php echo e(old('meta_title', $blog->meta_title ?? '')); ?>">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="form-label">Meta Keyword</label>
            <input type="text" name="meta_keyword" class="form-control" value="<?php echo e(old('meta_keyword', $blog->meta_keyword ?? '')); ?>">
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group">
            <label class="form-label">Meta Description</label>
            <textarea name="meta_description" class="form-control"><?php echo e(old('meta_description', $blog->meta_description ?? '')); ?></textarea>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/blog/form.blade.php ENDPATH**/ ?>