<?php echo $__env->make('admin.partial.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<div class="content-wrapper">






<div class="flex-grow-1 container-p-y container-xxl">
    <div class="card">
        <!-- <h5 class="card-header">VinSearch</h5> -->
        
        <div class="container">

<h1> Auction Performance Report </br> Coming Soon</h1>

        <?php echo $__env->make('admin.partial.soon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



    </div>
</div>






















<?php echo $__env->make('admin.partial.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/reportsanalytics/auctionperformancereport.blade.php ENDPATH**/ ?>