<?php $__env->startSection('css'); ?>

<style>
  
    

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
  

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.partial.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('web.partial.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/web/feautres.blade.php ENDPATH**/ ?>