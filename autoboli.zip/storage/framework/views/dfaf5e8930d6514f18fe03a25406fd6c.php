
<?php $__env->startPush('title'); ?> All Interest <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>

<style>
   .dataTables_length{
      display:none!important;
   }

   .table{
    width: 100%!important;
   }

   .dataTables_info{
      /* display: inline!important; */
   }

   .datatables-products th {
      text-align: center;
   }
   .datatables-products td {
      text-align: center;
   }

   .table-responsive {
      overflow-x: auto!important;
      -webkit-overflow-scrolling: touch!important;
   }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container-fluid container-p-y">
      <div class="row g-6"> 
            <div class="col-md-12">

                        

                 <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                  <?php endif; ?>

                <div class="card">
                    <div class="card-header border-bottom">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="card-title ">All Interest</h5>
                            </div>
                            <div class="col-md-6 text-end">
                                 <a href="<?php echo e(url('/interest/create')); ?>" class="btn btn-primary">Create Interest</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">

                        <div class="row pt-5">
                            <div class="col-md-8">
                                <select style="max-width:200px;padding:5px;"  name="length" class="">
                                    <option value="10">10</option>
                                    <option value="100">100</option>
                                    <option value="200">200</option>
                                    <option value="500">500</option>
                                </select>
                                <span style="padding-left: 5px" class="pl-2 pageinfo">0</span>
                            </div>
                            <div class="col-md-4 text-end">
                              <input style="max-width: 300px"  placeholder="Search.." type="text" class="d-inline form-control" name="search"  />
                            </div>
                        </div>

                        <div class="pt-5 table-responsive text-nowrap">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                       <th>#</th>
                                       <th>Name</th>
                                       <th>Make</th>
                                       <th>Model</th>
                                       <th>Variant</th>
                                       <th>Year</th>
                                       <th>Mileage</th>
                                       <th>CC</th>
                                       <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0"></tbody>
                            </table>
                        </div>
                    </div>  
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
            $(document).ready(function () {
             let table = $('table').DataTable({
                    processing: true,
                    serverSide: true,
                    ordering:false,
                    ajax: "<?php echo e(url('/interest')); ?>",
                });

                table.on('draw.dt', function () {
                    var info = table.page.info();
                    $('.pageinfo').html(`Showing ${info.start + 1} to ${info.end} of ${info.recordsDisplay} entries`);
                });

                $("input[name='search']").on('keyup change', function () {
                    table.search(this.value).draw();
                });

                $("select[name='length']").on('change', function () {
                    const length = $(this).val();
                    table.page.len(length).draw();
                }).trigger('change');

            });
    </script>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/user/interests/index.blade.php ENDPATH**/ ?>