<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <label class="form-label" >Plan Name</label>
            <input type="text" name="plan_name" class="form-control" value="<?php echo e(old('plan_name', $plan->plan_name ?? '')); ?>" required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
             <label class="form-label">Short Description</label>
             <input type="text" name="short_desc" class="form-control" value="<?php echo e(old('short_desc', $plan->short_desc ?? '')); ?>" required>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
             <label class="form-label">Price</label>
             <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', $plan->price ?? '')); ?>" required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
             <label class="form-label">Duration Unit</label>
            <select name="duration_unit" class="form-control" required>
                <option value="">Select</option>
                <option value="day" <?php echo e((old('duration_unit', $plan->duration_unit ?? '') == 'day') ? 'selected' : ''); ?>>Day</option>
                <option value="month" <?php echo e((old('duration_unit', $plan->duration_unit ?? '') == 'month') ? 'selected' : ''); ?>>Month</option>
                <option value="year" <?php echo e((old('duration_unit', $plan->duration_unit ?? '') == 'year') ? 'selected' : ''); ?>>Year</option>
            </select>
        </div>
    </div>
     <div class="col-md-4">
        <div class="form-group">
             <label class="form-label">Duration Value</label>
            <input type="number" name="duration_value" class="form-control" value="<?php echo e(old('duration_value', $plan->duration_value ?? '')); ?>" required>
        </div>
    </div>

    <div class="col-md-12">
        <div class="form-group">
             <label class="form-label">Description</label>
             <textarea name="description" class="form-control"><?php echo e(old('description', $plan->description ?? '')); ?></textarea>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/plans/form.blade.php ENDPATH**/ ?>