
<?php $__env->startPush('title'); ?> Tickets <?php $__env->stopPush(); ?>
<?php $__env->startSection('css'); ?>
<style>

    .table{
        width: 100%!important;
    }

    .dataTables_length{
        display:none!important;
    }

    .dataTables_info{
        
    }

    .datatables-products th {
        text-align: center;
    }
    .datatables-products td {
        text-align: center;
    }

    .table-responsive {
        overflow-x: auto!important;
        -webkit-overflow-scrolling: touch!important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid py-4">
    <div class="card mb-4">
        <div class="card-header">
            <h4 class="mb-0">Ticket #<?php echo e($ticket->id); ?> - <?php echo e($ticket->issue_topic); ?></h4>
        </div>
        <div class="card-body">
            <p><strong>User:</strong> <?php echo e($ticket->user->firstName); ?> <?php echo e($ticket->user->surname); ?></p>
            <p>
                <strong>Status:</strong>
                <span class="badge 
                    <?php echo e($ticket->status == 0 ? 'bg-warning' : 
                       ($ticket->status == 1 ? 'bg-info' : 
                       ($ticket->status == 2 ? 'bg-success' : 'bg-secondary'))); ?>">
                    <?php echo e(['Open','In Progress','Resolved','Closed'][$ticket->status]); ?>

                </span>
            </p>
            <p>
                <strong>Priority:</strong>
                <span class="badge 
                    <?php echo e($ticket->priority == 'High' ? 'bg-danger' : 
                       ($ticket->priority == 'Medium' ? 'bg-warning' : 'bg-success')); ?>">
                    <?php echo e($ticket->priority); ?>

                </span>
            </p>
            <p><strong>Details:</strong><br><?php echo e($ticket->details); ?></p>
            <?php if($ticket->attachment): ?>
                <p><strong>Attachment:</strong> <a href="<?php echo e(asset('storage/' . $ticket->attachment)); ?>" target="_blank">View File</a></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Send a Reply</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(url('/admin/tickets/'.$ticket->id.'/reply')); ?>">
                <?php echo csrf_field(); ?>
                <textarea name="message" class="form-control" rows="3" required placeholder="Type your reply..."></textarea>
                <button type="submit" class="btn btn-primary mt-2">Send Reply</button>
            </form>
        </div>
    </div>

    <?php if($ticket->replies->count()): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Previous Replies</h5>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $ticket->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-3 p-3 border rounded">
                        <strong><?php echo e($reply->is_admin ? 'Admin' : $reply->user->firstName); ?>:</strong>
                        <p class="mb-0"><?php echo e($reply->message); ?></p>
                        <small class="text-muted"><?php echo e($reply->created_at->format('d M Y H:i')); ?></small>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Update Ticket</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(url('/admin/tickets/'.$ticket->id.'/update')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row gy-3">
                    <div class="col-md-6">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="0" <?php echo e($ticket->status == 0 ? 'selected' : ''); ?>>Open</option>
                            <option value="1" <?php echo e($ticket->status == 1 ? 'selected' : ''); ?>>In Progress</option>
                            <option value="2" <?php echo e($ticket->status == 2 ? 'selected' : ''); ?>>Resolved</option>
                            <option value="3" <?php echo e($ticket->status == 3 ? 'selected' : ''); ?>>Closed</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Priority</label>
                        <select name="priority" class="form-select">
                            <option value="Low" <?php echo e($ticket->priority == 'Low' ? 'selected' : ''); ?>>Low</option>
                            <option value="Medium" <?php echo e($ticket->priority == 'Medium' ? 'selected' : ''); ?>>Medium</option>
                            <option value="High" <?php echo e($ticket->priority == 'High' ? 'selected' : ''); ?>>High</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-success mt-3">Update Ticket</button>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Ticket Rating & Feedback (Admin View Only)</h5>
        </div>
        <div class="card-body">
            <p><strong>Rating:</strong> <?php echo e($ticket->rating ?? 'No rating provided'); ?> / 5</p>
            <p><strong>Feedback:</strong> <?php echo e($ticket->feedback ?? 'No feedback provided'); ?></p>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partial.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\autoboli\resources\views/admin/tickets/show.blade.php ENDPATH**/ ?>